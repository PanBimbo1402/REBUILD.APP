'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {inventory,inspect}=require('../scripts/owner-build.cjs');
test('owner receipt verifies actual source bytes and rejects changed or added application files',t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'ixhua-owner-proof-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  for(const dir of ['js','css','assets','server','scripts','config'])fs.mkdirSync(path.join(root,dir));
  for(const file of ['index.html','manifest.json','package.json','build.cjs','START-IXHUA.bat','START-IXHUA.command','js/app.js'])fs.writeFileSync(path.join(root,file),'explicit source test fixture');
  const base='a83eeb03b8ff10dd4b57ce0551f25325a3a7f60f';
  fs.writeFileSync(path.join(root,'config/phone-preview.json'),JSON.stringify({ownerAcceptance:{baselineCommit:base}}));
  assert.equal(inspect(root).status,'DEVELOPMENT WORKING COPY');
  const receipt={schema:1,baselineCommit:base,commit:base,files:inventory(root)};
  fs.writeFileSync(path.join(root,'BUILD-IDENTITY.json'),JSON.stringify(receipt));
  assert.equal(inspect(root).verified,true);
  fs.appendFileSync(path.join(root,'js/app.js'),'changed');assert.equal(inspect(root).verified,false);
  fs.writeFileSync(path.join(root,'js/app.js'),'explicit source test fixture');assert.equal(inspect(root).verified,true);
  fs.writeFileSync(path.join(root,'js/unrelated.js'),'unfinished subsystem');assert.equal(inspect(root).verified,false);
  fs.unlinkSync(path.join(root,'js/unrelated.js'));assert.equal(inspect(root).verified,true);
  receipt.baselineCommit='0'.repeat(40);fs.writeFileSync(path.join(root,'BUILD-IDENTITY.json'),JSON.stringify(receipt));assert.equal(inspect(root).verified,false);
});
test('owner launch uses a separate port and identifies the two accepted checkpoints',()=>{
  const config=require('../config/phone-preview.json');
  assert.equal(config.defaultPort,4319);
  assert.equal(config.ownerAcceptance.baselineCommit,'a83eeb03b8ff10dd4b57ce0551f25325a3a7f60f');
  assert.equal(config.ownerAcceptance.runningCommit,'a412542e90f3f00d30ab36abb804d155fa8fbdf9');
  assert.deepEqual(config.checks.filter(x=>['runner','strength','hybrid','general','longevity','custom'].includes(x.id)).map(x=>x.id),['runner','strength','hybrid','general','longevity','custom']);
});
