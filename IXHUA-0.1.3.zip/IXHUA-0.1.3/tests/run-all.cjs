const {spawn}=require('node:child_process');
const server=spawn(process.execPath,['server/index.cjs'],{stdio:['ignore','pipe','inherit']});
server.stdout.once('data',async()=>{try{for(const args of [['--test','tests/engine.test.cjs'],['tests/server.cjs'],['tests/dom.cjs']]){await new Promise((resolve,reject)=>{const p=spawn(process.execPath,args,{stdio:'inherit'});p.on('exit',code=>code===0?resolve():reject(Error('Test failed: '+args.join(' '))));});}}catch(e){console.error(e.message);process.exitCode=1;}finally{server.kill();}});
server.on('error',e=>{console.error(e);process.exitCode=1;});
