'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const vm=require('node:vm');
const {webcrypto}=require('node:crypto');
const {spawn}=require('node:child_process');
const {JSDOM,VirtualConsole}=require('jsdom');
const {createServer}=require('../server/index.cjs');
const {createPhonePreview,qrSvg}=require('../server/phone-preview.cjs');
const {privateIPv4,lanAddresses}=require('../scripts/preview-network.cjs');
const root=path.resolve(__dirname,'..');
// These are explicitly synthetic network fixtures, not detected hardware or a live phone.
const adapters=[{name:'Wi-Fi test fixture',address:'192.168.50.21',virtual:false}];
async function fixture(t,options={}) {
  let preview;
  const server=createServer({preview:{handle:(...args)=>preview.handle(...args)}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const port=server.address().port;
  preview=createPhonePreview({addresses:adapters,port,env:{},...options});
  t.after(()=>{server.close();server.closeAllConnections();});
  const base=`http://127.0.0.1:${port}`;
  const link=new URL(preview.makeLink('127.0.0.1'));
  const hash=new URLSearchParams(link.hash.slice(1));
  const pairing={token:hash.get('access'),buildId:hash.get('build')};
  async function pair(data=pairing,headers={}) {
    return fetch(base+'/preview/pair',{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(data)});
  }
  async function cookie() {const result=await pair();assert.equal(result.status,200);return result.headers.get('set-cookie').split(';')[0];}
  return {server,preview,base,port,pairing,pair,cookie};
}
test('LAN address detection selects physical adapters, filters invalid/public/internal addresses and deduplicates',()=>{
  const values=lanAddresses({
    'vEthernet (WSL)':[{address:'172.20.1.2',family:'IPv4',internal:false}],
    'Wi-Fi':[{address:'192.168.1.20',family:4,internal:false},{address:'fe80::12',family:'IPv6',internal:false}],
    'Ethernet':[{address:'10.0.0.4',internal:false},{address:'192.168.1.20',internal:false}],
    'Loopback':[{address:'127.0.0.1',internal:true}],
    'Public':[{address:'203.0.113.5',internal:false},{address:'169.254.2.4',internal:false}]
  });
  assert.deepEqual(values.map(x=>x.address),['10.0.0.4','192.168.1.20','172.20.1.2']);
  assert.deepEqual(lanAddresses({}),[]);
});
test('private address boundaries reject hosts, malformed IPs, and public addresses',()=>{
  for(const value of ['10.0.0.1','172.16.0.1','172.31.255.254','192.168.1.1'])assert.equal(privateIPv4(value),true,value);
  for(const value of ['172.15.0.1','172.32.0.1','192.167.0.1','192.169.0.1','8.8.8.8','localhost','10.0.0.999','10.1.1.1;cmd','127.0.0.1','0.0.0.0','::1'])assert.equal(privateIPv4(value),false,value);
});
test('LAN HTTP IDs work without secure-context randomUUID and have valid UUIDv4 bits',()=>{
  const window={crypto:{getRandomValues:array=>webcrypto.getRandomValues(array)}};
  vm.runInNewContext(fs.readFileSync(path.join(root,'js/platform.js'),'utf8'),{window,Uint8Array});
  const ids=new Set(Array.from({length:256},()=>window.REBUILD_RECORD_ID()));
  assert.equal(ids.size,256);
  for(const id of ids)assert.match(id,/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
});
test('missing cryptographic browser primitive fails explicitly instead of using weak or duplicate IDs',()=>{
  const window={};vm.runInNewContext(fs.readFileSync(path.join(root,'js/platform.js'),'utf8'),{window,Uint8Array});
  assert.throws(()=>window.REBUILD_RECORD_ID(),/cannot create record IDs/);
});
test('health is scoped to this process and does not reveal pairing token or configured secrets',async t=>{
  const f=await fixture(t,{env:{OPENAI_API_KEY:'unit-test-secret',REBUILD_AI_MODEL:'unit-test-model',OFF_USER_AGENT:'test'}});
  const result=await fetch(f.base+'/preview/health'),text=await result.text();
  assert.equal(result.status,200);assert.equal(JSON.parse(text).nonce,f.preview.nonce);
  assert.equal(JSON.parse(text).buildId,f.preview.buildId);
  assert.ok(!text.includes(f.pairing.token));assert.ok(!text.includes('unit-test-secret'));
});
test('unpaired app, assets, API and capability requests are refused',async t=>{
  const f=await fixture(t);
  for(const p of ['/','/js/app.js','/assets/anatomy-3d-front-back.png','/api/coach','/preview/status'])assert.equal((await fetch(f.base+p)).status,401,p);
});
test('pairing sets an HttpOnly strict cookie and serves the identical existing app and script bytes',async t=>{
  const f=await fixture(t);const pair=await f.pair();
  const cookie=pair.headers.get('set-cookie');
  assert.match(cookie,/HttpOnly/);assert.match(cookie,/SameSite=Strict/);assert.match(cookie,/Max-Age=/);
  for(const p of ['/index.html','/js/app.js','/js/engine.js','/js/platform.js','/js/preview-client.js']){
    const response=await fetch(f.base+p,{headers:{Cookie:cookie.split(';')[0]}});assert.equal(response.status,200,p);
    assert.equal(await response.text(),fs.readFileSync(path.join(root,p),'utf8'),p);
  }
});
test('wrong token, wrong build and old cookies cannot pair',async t=>{
  const f=await fixture(t);
  assert.equal((await f.pair({...f.pairing,token:'invalid'})).status,401);
  assert.equal((await f.pair({...f.pairing,buildId:'wrong-build'})).status,401);
  assert.equal((await fetch(f.base+'/preview/status',{headers:{Cookie:'ixhua_preview='+'0'.repeat(64)}})).status,401);
});
test('both link and session expire; expired states never stay ready',async t=>{
  let now=Date.now();const f=await fixture(t,{clock:()=>now,ttlMs:10000});
  const cookie=await f.cookie();now+=10001;
  assert.equal((await f.pair()).status,401);
  assert.equal((await fetch(f.base+'/preview/status',{headers:{Cookie:cookie}})).status,401);
  assert.equal((await(await fetch(f.base+'/preview/health')).json()).ready,false);
});
test('server restart invalidates previous sessions and invitation tokens',async t=>{
  const first=await fixture(t),cookie=await first.cookie(),second=await fixture(t);
  assert.equal((await second.pair(first.pairing)).status,401);
  assert.equal((await fetch(second.base+'/preview/status',{headers:{Cookie:cookie}})).status,401);
});
test('cross-origin pairing and API calls are denied',async t=>{
  const f=await fixture(t),cookie=await f.cookie();
  assert.equal((await f.pair(f.pairing,{Origin:'https://attacker.example'})).status,403);
  assert.equal((await fetch(f.base+'/api/coach',{method:'POST',headers:{Origin:'https://attacker.example',Cookie:cookie,'Content-Type':'application/json'},body:'{}'})).status,403);
});
test('the paired app reaches the actual backend validation handler',async t=>{
  const f=await fixture(t),cookie=await f.cookie();
  const response=await fetch(f.base+'/api/coach',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'});
  assert.equal(response.status,400);
  assert.match((await response.json()).error,/question and IXHUA context/);
});
test('host-header attacks are denied and forwarded headers do not authorize another origin',async t=>{
  const f=await fixture(t);
  const status=await new Promise((resolve,reject)=>{
    http.get(f.base+'/owner-preview',{headers:{Host:`attacker.example:${f.port}`,'X-Forwarded-For':'127.0.0.1'}},response=>{response.resume();resolve(response.statusCode);}).on('error',reject);
  });
  assert.equal(status,403);
});
test('QR control page rejects real non-loopback peers, including forged forwarded headers',async t=>{
  const f=await fixture(t);
  let code;
  const res={setHeader(){},writeHead(value){code=value;},end(){}};
  await f.preview.handle({url:'/owner-preview',method:'GET',headers:{host:`192.168.50.21:${f.port}`,'x-forwarded-for':'127.0.0.1'},socket:{remoteAddress:'192.168.50.99'}},res);
  assert.equal(code,403);
  await f.preview.handle({url:'/',method:'GET',headers:{host:`192.168.50.21:${f.port}`},socket:{remoteAddress:'203.0.113.5'}},res);
  assert.equal(code,403);
});
test('pairing validates content type and size and handles malformed JSON',async t=>{
  const f=await fixture(t);
  assert.equal((await f.pair(f.pairing,{'Content-Type':'text/plain'})).status,415);
  assert.equal((await f.pair({...f.pairing,token:'x'.repeat(1200)})).status,413);
  assert.equal((await fetch(f.base+'/preview/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:'{'})).status,400);
});
test('repeated invalid pair attempts are rate limited',async t=>{
  const f=await fixture(t);
  for(let i=0;i<10;i++)assert.equal((await f.pair({token:`wrong-${i}`,buildId:f.pairing.buildId})).status,401);
  assert.equal((await f.pair()).status,429);
});
test('paired requests cannot read server files, env files, arbitrary paths or QR controls through an alias',async t=>{
  const f=await fixture(t),cookie=await f.cookie();
  for(const p of ['/server/index.cjs','/.env','/.env.example','/scripts/start-ixhua.cjs','/package.json','/config/phone-preview.json','/certs/private.key','/preview/unknown'])assert.equal((await fetch(f.base+p,{headers:{Cookie:cookie}})).status,404,p);
});
test('capability status cannot claim native validation or full RC success',async t=>{
  const f=await fixture(t),cookie=await f.cookie();
  const status=await(await fetch(f.base+'/preview/status',{headers:{Cookie:cookie}})).json();
  assert.equal(status.releaseGate.eligibleForOwnerAcceptance,false);
  assert.ok(status.releaseGate.blockers.some(x=>x.id==='media'));
  assert.equal(status.releaseGate.physicalIPhone,'NOT RUN BY BUILD ENVIRONMENT');
  assert.equal(status.releaseGate.nativeBeta,'REQUIRES EXPLICIT OWNER APPROVAL');
  assert.ok(status.nativeOnly.some(x=>x.includes('HealthKit')));
  assert.equal(status.services[1].state,'NOT CONFIGURED');
});
test('having credentials or a staging database is not counted as a successful live integration',async t=>{
  const f=await fixture(t,{env:{OPENAI_API_KEY:'not-a-real-key',REBUILD_AI_MODEL:'not-a-real-model',OFF_USER_AGENT:'test'}});
  const status=f.preview.status();
  assert.equal(status.services[1].state,'CONFIGURED — LIVE TEST REQUIRED');
  assert.equal(status.services[2].state,'STAGING — LIVE PRODUCT TEST BLOCKED');
  assert.equal(status.releaseGate.eligibleForOwnerAcceptance,false);
});
test('owner QR is inline, locally generated and points to the same server, not localhost on the phone',async t=>{
  const f=await fixture(t),response=await fetch(f.base+'/owner-preview'),html=await response.text();
  assert.equal(response.status,200);
  assert.ok(html.includes('data:image/svg+xml;base64,'));
  const svg=Buffer.from(/data:image\/svg\+xml;base64,([^" ]+)/.exec(html)[1],'base64').toString();
  assert.ok(svg.includes('shape-rendering="crispEdges"'));
  assert.ok(html.includes(`http://192.168.50.21:${f.port}/pair#access=`));
  assert.ok(!html.includes('api.qrserver'));assert.ok(!html.includes('chart.googleapis'));
  assert.ok(response.headers.get('content-security-policy').includes("img-src data:"));
  assert.ok(svg.includes('fill="white"'));assert.ok(svg.includes('fill="black"'));
});
test('no detected LAN produces a blocking message and no fake phone QR',async t=>{
  const f=await fixture(t,{addresses:[]});const html=await(await fetch(f.base+'/owner-preview')).text();
  assert.ok(html.includes('Phone preview is not ready'));assert.ok(!html.includes('data:image/svg+xml;base64,'));
  assert.ok(html.includes('Open the same app on this computer'));
});
test('owner review DOM keeps checks unrun, saves explicit results, labels native limits and persists by build',async t=>{
  const f=await fixture(t);
  const status=f.preview.status(),errors=[];
  const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM('<!doctype html><html><head></head><body><main id="existing-product">Real product content</main></body></html>',{url:f.base,runScripts:'outside-only',virtualConsole:vc});
  t.after(()=>dom.window.close());const w=dom.window;
  w.fetch=async()=>({ok:true,json:async()=>status});w.AbortSignal=AbortSignal;
  w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};
  w.HTMLDialogElement.prototype.close=function(){this.dispatchEvent(new w.Event('close'));};
  w.eval(fs.readFileSync(path.join(root,'js/preview-client.js'),'utf8'));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(w.document.querySelectorAll('.ixhua-preview-banner').length,1);
  w.document.querySelector('.ixhua-preview-banner').click();await new Promise(resolve=>setImmediate(resolve));
  const dialog=w.document.querySelector('dialog');assert.ok(dialog);
  assert.ok(dialog.textContent.includes('Requires Native Device Beta'));
  for(const select of dialog.querySelectorAll('[data-review-check]'))assert.equal(select.value,'NOT RUN');
  dialog.querySelector('[data-review-check="strength"]').value='PASS';
  dialog.querySelector('[data-review-check="hybrid"]').value='BLOCKED';
  dialog.querySelector('input[name="device"]').value='Explicit test fixture';
  dialog.querySelector('form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
  const saved=JSON.parse(w.localStorage.getItem('ixhua-owner-phone-review:'+status.buildId));
  assert.equal(saved.results.strength,'PASS');assert.equal(saved.results.hybrid,'BLOCKED');assert.equal(saved.physicalPhone,false);
  assert.equal(saved.approval,'NOT GRANTED BY THIS RECORD');assert.equal(saved.nativeValidation,'NOT CLAIMED');
  assert.equal(saved.releaseGate.eligibleForOwnerAcceptance,false);
  dialog.querySelector('#ixhua-review-close').click();w.document.querySelector('.ixhua-preview-banner').click();
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(w.document.querySelector('[data-review-check="strength"]').value,'PASS');
  assert.equal(w.document.querySelector('#existing-product').textContent,'Real product content');
  assert.deepEqual(errors,[]);
});
test('pairing page erases the URL fragment before submitting and provides clear failure text',async t=>{
  const f=await fixture(t);
  const dom=new JSDOM('<p id="pair-status"></p>',{url:f.preview.makeLink('127.0.0.1'),runScripts:'outside-only'});t.after(()=>dom.window.close());
  const w=dom.window;let calls=0;w.AbortSignal=AbortSignal;
  w.fetch=async(url,options)=>{calls++;assert.equal(w.location.hash,'');assert.equal(url,'/preview/pair');assert.deepEqual(JSON.parse(options.body),f.pairing);return{ok:false,json:async()=>({error:'Expired test invitation'})};};
  w.eval(fs.readFileSync(path.join(root,'js/preview-pair.js'),'utf8'));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(calls,1);assert.equal(w.location.hash,'');assert.equal(w.document.querySelector('p').textContent,'Expired test invitation');
});
test('launcher detects occupied port and leaves the existing service running',async t=>{
  const server=http.createServer((req,res)=>res.end('existing-service'));
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>{server.close();server.closeAllConnections();});
  const port=server.address().port;
  const result=await new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,[path.join(root,'scripts/start-ixhua.cjs'),'--no-open'],{cwd:path.dirname(root),env:{...process.env,IXHUA_PREVIEW_PORT:String(port),IXHUA_PREVIEW_ADDRESS:'',IXHUA_PREVIEW_TLS_CERT:'',IXHUA_PREVIEW_TLS_KEY:''},stdio:['ignore','pipe','pipe']});
    let output='';child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>output+=b);child.on('error',reject);child.on('exit',code=>resolve({code,output}));
  });
  assert.equal(result.code,1);assert.match(result.output,/already in use/);
  assert.equal(await(await fetch(`http://127.0.0.1:${port}`)).text(),'existing-service');
});
test('launcher can start outside the project folder and stop all of its services',async t=>{
  const reserve=http.createServer();await new Promise(resolve=>reserve.listen(0,'127.0.0.1',resolve));
  const port=reserve.address().port;await new Promise(resolve=>reserve.close(resolve));
  const child=spawn(process.execPath,[path.join(root,'scripts/start-ixhua.cjs'),'--no-open'],{cwd:path.dirname(root),env:{...process.env,IXHUA_PREVIEW_PORT:String(port),IXHUA_PREVIEW_ADDRESS:'',IXHUA_PREVIEW_TLS_CERT:'',IXHUA_PREVIEW_TLS_KEY:''},stdio:['ignore','pipe','pipe']});
  t.after(()=>child.kill('SIGTERM'));
  let output='';
  await new Promise((resolve,reject)=>{
    const timeout=setTimeout(()=>reject(new Error('Launcher did not become ready: '+output)),8000);
    const data=b=>{output+=b;if(output.includes('Press Ctrl+C to stop')){clearTimeout(timeout);resolve();}};
    child.stdout.on('data',data);child.stderr.on('data',data);child.once('error',reject);child.once('exit',code=>{if(!output.includes('Press Ctrl+C to stop')){clearTimeout(timeout);reject(new Error('Launcher exited: '+code+' '+output));}});
  });
  assert.equal((await fetch(`http://127.0.0.1:${port}/preview/health`)).status,200);
  assert.match(output,/App \+ backend: RUNNING/);
  const exited=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');assert.equal(await exited,0);
  await assert.rejects(fetch(`http://127.0.0.1:${port}/preview/health`));
});
