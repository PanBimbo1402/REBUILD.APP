'use strict';
const {test}=require('node:test'),a=require('node:assert/strict');
const C=require('../js/ixhua/core'),T=require('../js/ixhua/training'),R=require('../js/ixhua/running'),E=require('../js/ixhua/exercises');
const {personas}=require('./athlete-fixtures.cjs');
const plan=p=>T.buildPlan(p,[],[],'2026-09-14',1);
test('A: three requested beginner runs survive supporting strength; separate lifting experience',()=>{const g=plan(personas.A);a.equal(g.sessions.filter(s=>s.type==='running').length,3);a.equal(g.sessions.filter(s=>s.type==='strength').length,0);a.ok(g.sessions.every(s=>s.runKind==='runwalk'&&s.segments.some(x=>x.kind==='walk')));a.equal(personas.A.strength.experience,'experienced');});
test('B: experienced runner receives goal-specific running, distinct from A',()=>{const runs=plan(personas.B).sessions.filter(s=>s.type==='running');a.equal(runs.length,6);a.ok(runs.some(s=>s.runKind==='interval'));a.ok(runs.some(s=>s.runKind==='long'));a.ok(runs.every(s=>s.type!=='cardio'));});
test('C / D: novice full-body and five-day arm hypertrophy produce different doses and exercises',()=>{const c=plan(personas.C).sessions,d=plan(personas.D).sessions;a.equal(c.length,3);a.ok(c.every(s=>s.architecture==='full'));a.equal(d.length,5);a.ok(d.every(s=>s.architecture==='hypertrophy'));a.ok(d.some(s=>s.title==='Arms & shoulders'));a.ok(d.flatMap(s=>s.exercises).filter(e=>/curl|triceps/i.test(e.name)).length>c.flatMap(s=>s.exercises).filter(e=>/curl|triceps/i.test(e.name)).length);});
test('E: hybrid goals share a real integrated six-day schedule',()=>{const ss=plan(personas.E).sessions;a.equal(ss.filter(s=>s.type==='running').length,3);a.equal(ss.filter(s=>s.type==='strength').length,3);for(const date of [...new Set(ss.map(s=>s.date))])a.ok(ss.filter(s=>s.date===date&&s.stress==='high').length<=1,'no day should contain two high-demand core sessions');});
test('Hybrid priority protects the selected objective without deleting the other goal when only three days fit',()=>{const running=C.normalProfile({...personas.E,days:[1,3,5],hybridPriority:'running'}),strength=C.normalProfile({...personas.E,days:[1,3,5],hybridPriority:'strength'});const rp=plan(running).sessions,sp=plan(strength).sessions;for(const ss of [rp,sp]){a.ok(ss.some(s=>s.type==='running'));a.ok(ss.some(s=>s.type==='strength'));}a.ok(rp.filter(s=>s.type==='running').length>rp.filter(s=>s.type==='strength').length);a.ok(sp.filter(s=>s.type==='strength').length>sp.filter(s=>s.type==='running').length);});
test('F / G: general and longevity have real aerobic and capability work; age is not a novice override',()=>{const f=plan(personas.F).sessions,g=plan(personas.G).sessions;a.equal(f.filter(s=>s.type==='strength').length,2);a.ok(f.some(s=>s.type==='cardio'&&s.mode==='bike'));a.ok(g.some(s=>s.type==='capability'&&s.exercises.some(e=>e.name==='Tandem Walk')));a.ok(g.filter(s=>s.type==='strength').some(s=>s.exercises.some(e=>e.plannedSets===3)));});
test('Custom qualities all influence the plan',()=>{const ss=plan(personas.H).sessions;for(const t of ['cardio','mobility','capability'])a.ok(ss.some(s=>s.type===t),t);});
test('Capability baseline changes aerobic duration and supported movement',()=>{const p=C.normalProfile({...personas.G,capability:{balance:5,chairStands:5,walkMinutes:8}});a.ok(T.capability(p).exercises.some(e=>e.name==='Supported Single-Leg Balance'));a.ok(T.strength(p).exercises.some(e=>e.name==='Chair Stand'));a.ok(T.cardio(p).minutes<=8);});
test('Plyometric readiness withholds, prepares, introduces and advances only with real feedback',()=>{let p=C.normalProfile({...personas.A,plyo:{enabled:true,pain:true,surface:'track',landing:'comfortable',experience:'experienced'}});a.equal(T.plyometrics(p).contacts,0);p.plyo.pain=false;p.plyo.surface='concrete';a.equal(T.plyoLevel(p).level,'withheld');p.plyo.surface='track';p.plyo.landing='learning';a.equal(T.plyometrics(p).contacts,0);p.plyo.landing='comfortable';a.equal(T.plyoLevel(p).level,'intro');const logs=Array.from({length:3},()=>({type:'plyo',status:'completed',metrics:{landing:'comfortable',pain:false}}));a.equal(T.plyoLevel(p,logs).level,'reactive');a.ok(T.plyometrics(p,0,logs).contacts>0);});
test('Equipment and short windows produce executable sessions, no empty placeholders',()=>{for(const minutes of [10,15,25,45]){const p=C.normalProfile({...personas.C,minutes,equipment:['bodyweight']});const s=T.strength(p);a.ok(s.exercises.length>0);a.ok(s.minutes<=minutes);a.ok(s.exercises.every(e=>e.equipment==='bodyweight'));}});
test('Preferences and running constraints alter the integrated prescription while default R is preserved',()=>{const p=C.normalProfile({...personas.B,running:{...personas.B.running,preference:'runwalk'}}),s=T.demands(p,[],'2026-09-14').filter(s=>s.type==='running');a.ok(s.every(s=>s.segments.some(x=>x.kind==='walk')));const quiet=C.normalProfile({...personas.B,running:{...personas.B.running,preference:'simple'}});a.ok(!T.demands(quiet,[],'2026-09-14').some(s=>s.runKind==='interval'));const pain=C.normalProfile({...personas.B,running:{...personas.B.running,pain:true}});a.ok(!plan(pain).sessions.some(s=>s.type==='running'));a.equal(R.prescription(personas.B,1,[],'2026-09-14').runKind,'interval');});
test('Schedule wake/sleep, events and commute buffers affect actual appointments',()=>{const p=personas.C,event={id:'shift',date:'2026-09-14',start:'06:00',end:'17:00'};const g=T.buildPlan(p,[],[event],'2026-09-14',1);a.ok(g.sessions.filter(s=>s.date===event.date).every(s=>R.minutesOf(s.time)>=17*60+30));for(const s of g.sessions)a.ok(R.minutesOf(s.time)+s.minutes<=R.minutesOf(p.schedule.bed));});
test('Working-set progression needs complete actual sets and RIR; repeated failure reduces load',()=>{const e={...E.get('Bench Press'),repRange:[8,12]},p={...personas.D,units:'metric'},s=(reps,rir)=>({type:'strength',status:'completed',units:'metric',exercises:[{id:e.id,name:e.name,sets:[{done:true,reps,rir,weightKg:60},{done:true,reps,rir,weightKg:60}]}]});a.equal(T.progression(e,[s(12,2)],p).weightKg,62.5);a.equal(T.progression(e,[s(12,null)],p).weightKg,60);a.equal(T.progression(e,[s(6,0),s(6,0)],p).weightKg,54);});
test('Structured exercise library has disjoint exercise-specific anatomy roles',()=>{E.validate();a.ok(E.library.length>=73);a.notDeepEqual(E.get('Bench Press').primary,E.get('Squat').primary);});
module.exports={personas};
test('Nutrition targets consume independent nutrition goal, physiology, activity, athlete role and manual choice',()=>{const N=require('../js/ixhua/athlete-nutrition');const p=personas.D,t=N.targets(p);a.ok(t.cal>0);a.equal(t.cal,t.maintenance);a.equal(t.proteinPerKg,1.8);a.ok(N.targets(C.normalProfile({...p,nutrition:{goal:'lose'}})).cal<t.cal);a.ok(N.targets(C.normalProfile({...p,nutrition:{activity:'high'}})).cal>t.cal);a.equal(N.targets(C.normalProfile({...p,sex:null})),null);a.equal(N.targets(C.normalProfile({...p,nutrition:{manualOnly:true}})),null);a.deepEqual(N.targets(p,{cal:2400,p:160,c:290,f:70}),{cal:2400,p:160,c:290,f:70,estimated:false,manual:true});});
test('Diet, allergy, dislike and preferred foods actually filter / order meal suggestions',()=>{const N=require('../js/ixhua/athlete-nutrition'),catalog=[{name:'Chicken bowl',foods:['chicken','rice']},{name:'Yogurt bowl',foods:['yogurt','oats']},{name:'Bean bowl',foods:['beans','rice']}];a.deepEqual(N.meals(catalog,C.normalProfile({...personas.F,nutrition:{diet:'vegan'}})).map(x=>x.name),['Bean bowl']);a.deepEqual(N.meals(catalog,C.normalProfile({...personas.F,nutrition:{allergies:['milk'],dislikes:['chicken']}})).map(x=>x.name),['Bean bowl']);a.equal(N.meals(catalog,C.normalProfile({...personas.F,nutrition:{likes:['beans']}}))[0].name,'Bean bowl');});
test('Running Progress respects the date range selected in the athlete product',()=>{const vm=require('node:vm'),fs=require('node:fs'),window={IXHUA_CORE:C,IXHUA_RUNNING:R},sandbox={window};vm.runInNewContext(fs.readFileSync(require.resolve('../js/ixhua/running-ui'),'utf8'),sandbox);window.IXHUA_RUN_UI.init({state:{athlete:personas.A,sessions:[{id:'old',date:C.addDays(C.dateKey(),-40),status:'completed',type:'running',title:'Old completed run',elapsedMs:600000,metrics:{distanceKm:1}},{id:'recent',date:C.dateKey(),status:'completed',type:'running',title:'Recent completed run',elapsedMs:600000,metrics:{distanceKm:1}}]}});const html=window.IXHUA_RUN_UI.progress(7);a.ok(html.includes('Recent completed run'));a.ok(!html.includes('Old completed run'));});


test('Upper/Lower A and B use distinct exercise selections',()=>{const p=C.normalProfile({...personas.D,days:[1,2,4,5],strength:{...personas.D.strength,days:4,split:'upperlower'}});const ua=T.strength(p,0,[]),la=T.strength(p,1,[]),ub=T.strength(p,2,[]),lb=T.strength(p,3,[]);a.equal(ua.title,'Upper Body A');a.equal(ub.title,'Upper Body B');a.equal(la.title,'Lower Body A');a.equal(lb.title,'Lower Body B');a.notDeepEqual(ua.exercises.map(x=>x.name),ub.exercises.map(x=>x.name));a.notDeepEqual(la.exercises.map(x=>x.name),lb.exercises.map(x=>x.name));});

test('Equal Hybrid preserves both running and upper/lower strength across a constrained four-day week',()=>{const p=C.normalProfile({...personas.E,days:[1,2,4,6],hybridPriority:'equal',running:{...personas.E.running,days:3},strength:{...personas.E.strength,days:4}});const ss=plan(p).sessions,titles=ss.filter(s=>s.type==='strength').map(s=>s.title);a.ok(ss.filter(s=>s.type==='running').length>=2);a.ok(ss.filter(s=>s.type==='strength').length>=2);a.ok(titles.some(x=>/Upper Body/.test(x)));a.ok(titles.some(x=>/Lower Body/.test(x)));});
test('Hybrid priority changes strength dose instead of only relabeling it',()=>{const base=C.normalProfile({...personas.E,minutes:75,strength:{...personas.E.strength,experience:'experienced',days:4,split:'upperlower'}});const running=T.strength({...base,hybridPriority:'running'},1,[],{volumeMode:'hybrid-running'}),equal=T.strength({...base,hybridPriority:'equal'},1,[],{volumeMode:'hybrid-equal'}),strength=T.strength({...base,hybridPriority:'strength'},1,[],{volumeMode:'hybrid-strength'});const sets=x=>x.exercises.reduce((a,e)=>a+e.plannedSets,0);a.ok(sets(strength)>=sets(equal));a.ok(sets(equal)>=sets(running));a.equal(running.volumeMode,'hybrid-running');a.equal(strength.volumeMode,'hybrid-strength');});

test('Longevity defaults to simple presentation while other identities keep details',()=>{a.equal(C.normalProfile({...personas.G,primary:'longevity'}).presentation,'simple');a.equal(C.normalProfile({...personas.C,primary:'strength'}).presentation,'details');});

test('Three-day Equal Hybrid alternates the extra core slot instead of permanently deleting one modality',()=>{
  const p=C.normalProfile({...personas.E,days:[1,3,5],splitSessions:false,hybridPriority:'equal',startedOn:'2026-09-14',running:{...personas.E.running,days:3},strength:{...personas.E.strength,days:3}});
  const g=T.buildPlan(p,[],[],'2026-09-14',2),weeks=['2026-09-14','2026-09-21'].map(w=>g.sessions.filter(s=>s.week===w));
  for(const ss of weeks){a.equal(ss.length,3);a.ok(ss.some(s=>s.type==='running'));a.ok(ss.some(s=>s.type==='strength'));}
  const mix=weeks.map(ss=>[ss.filter(s=>s.type==='running').length,ss.filter(s=>s.type==='strength').length]);
  a.notDeepEqual(mix[0],mix[1]);
  a.equal(g.unplaced.length,0);
});

test('Three-day Equal Hybrid with one allowed split day plans 2 running + 2 strength core sessions without support-noise warnings',()=>{
  const p=C.normalProfile({...personas.E,days:[1,3,5],splitSessions:true,hybridPriority:'equal',startedOn:'2026-09-14',running:{...personas.E.running,days:3},strength:{...personas.E.strength,days:3}});
  const g=plan(p),ss=g.sessions;
  a.equal(ss.filter(s=>s.type==='running').length,2);
  a.equal(ss.filter(s=>s.type==='strength').length,2);
  a.ok(g.unplaced.every(x=>x.priority==='key'));
});

test('Hybrid core demands are never demoted to support just because one side has priority',()=>{
  for(const priority of ['running','equal','strength']){
    const p=C.normalProfile({...personas.E,days:[1,3,5],hybridPriority:priority,running:{...personas.E.running,days:3},strength:{...personas.E.strength,days:3}});
    const core=T.demands(p,[],'2026-09-14').filter(s=>s.type==='running'||s.type==='strength');
    a.ok(core.some(s=>s.type==='running'));
    a.ok(core.some(s=>s.type==='strength'));
    a.ok(core.every(s=>s.priority==='key'));
  }
});

test('Hybrid support blocks stay attached without replacing core sessions',()=>{
  const p=C.normalProfile({...personas.E,hybridPriority:'equal',plyo:{...personas.E.plyo,enabled:true,pain:false,surface:'track',landing:'comfortable'}});
  const demands=T.demands(p,[],'2026-09-14');
  const core=demands.filter(s=>['running','strength'].includes(s.type));
  a.ok(core.some(s=>s.type==='running'));
  a.ok(core.some(s=>s.type==='strength'));
  a.ok(core.every(s=>Array.isArray(s.support)&&s.support.some(x=>x.type==='mobility')));
  a.ok(core.filter(s=>s.type==='strength').some(s=>s.support.some(x=>x.type==='cardio'&&x.role==='finisher')));
});

test('Hybrid plyometric primer is quality-first and limited to suitable sessions rather than every day',()=>{
  const p=C.normalProfile({...personas.E,hybridPriority:'equal',plyo:{...personas.E.plyo,enabled:true,pain:false,surface:'track',landing:'comfortable'}});
  const core=T.demands(p,[],'2026-09-14').filter(s=>['running','strength'].includes(s.type));
  const primers=core.flatMap(s=>(s.support||[]).filter(x=>x.type==='plyo'&&x.role==='primer').map(x=>({parent:s,...x})));
  a.ok(primers.length>=1 && primers.length<=2);
  a.ok(primers.every(x=>x.minutes<=10));
  a.ok(primers.every(x=>x.weeklyIntent==='1–2 quality exposures'));
  a.ok(!primers.some(x=>x.parent.type==='running'&&x.parent.runKind==='long'));
});
