const a=require('node:assert/strict');
async function completeOnboarding(page,p,{reloadDraft=false}={}){
 const form=()=>page.locator('#ix-onboarding-form');
 const fill=async(name,value)=>{const x=form().locator('[name="'+name+'"]');if(await x.count())await x.fill(value==null?'':String(value));};
 const select=async(name,value)=>{const x=form().locator('[name="'+name+'"]');if(await x.count())await x.selectOption(String(value));};
 const checks=async(name,values)=>{for(const x of await form().locator('[name="'+name+'"]').all())await x.setChecked(values.map(String).includes(await x.getAttribute('value')));};
 const steps=[];
 for(let guard=0;guard<20&&await form().count();guard++){
  const step=await form().getAttribute('data-onboard-step');steps.push(step);
  if(step==='identity')await form().locator('[data-identity="'+p.primary+'"]').click();
  if(step==='priorities'){await checks('secondary',p.secondary);await select('hybridPriority',p.hybridPriority);await select('customPriority',p.customPriority||p.secondary[0]||'cardio');await fill('customGoal',p.customGoal||'');}
  if(step==='profile'){
   await fill('name','Test athlete '+p.primary);await fill('age',p.age);await select('sex',p.sex||'unspecified');await fill('feet',5);await fill('inches',11);await fill('weight',(p.weightKg*2.2046226218).toFixed(1));
   if(reloadDraft){await select('units','metric');a.ok(Math.abs(+(await form().locator('[name=heightCm]').inputValue())-180.3)<.2);a.ok(Math.abs(+(await form().locator('[name=weight]').inputValue())-p.weightKg)<.1);await page.reload();a.equal(await form().getAttribute('data-onboard-step'),'profile');a.equal(await form().locator('[name=age]').inputValue(),String(p.age));await select('units','imperial');a.equal(await form().locator('[name=feet]').inputValue(),'5');}
  }
  if(step==='runGoal'){await select('runGoal',p.running.goal);await select('runIntent',p.running.intent||(/faster/.test(p.running.goal)?'performance':'completion'));await fill('targetTime',p.running.targetSeconds?Math.floor(p.running.targetSeconds/60)+'.'+String(p.running.targetSeconds%60).padStart(2,'0'):'');await select('deadlineKind',p.running.goalDate?'date':'none');await fill('goalDate',p.running.goalDate);}
  if(step==='runBaseline'){await select('runExperience',p.running.experience);for(const [n,k]of [['continuous','continuousMinutes'],['weekly','weeklyMinutes'],['currentRunDays','currentDays'],['consistentWeeks','consistentWeeks'],['runDays','days'],['longMinutes','longMinutes']])await fill(n,p.running[k]);await select('longDay',p.running.longDay);await select('environment',p.running.environment);await select('runPreference',p.running.preference);if(reloadDraft){await fill('benchmarkTime','9.15');await fill('benchmarkDate','2026-09-01');await page.reload();a.equal(await form().locator('[name=benchmarkTime]').inputValue(),'9.15');await form().locator('#ix-onboard-back').click();await form().locator('[type=submit]').click();a.equal(await form().locator('[name=benchmarkTime]').inputValue(),'9.15');}}
  if(step==='strength'){await select('liftExperience',p.strength.experience);await select('liftGoal',p.strength.goal);await fill('currentLiftDays',p.strength.currentDays??(p.strength.experience==='new'?0:p.strength.days));await fill('liftWeeks',p.strength.consistentWeeks??(p.strength.experience==='new'?0:20));await fill('liftBreak',p.strength.breakWeeks||0);await fill('liftDays',p.strength.days);await select('split',p.strength.split);await checks('musclePriority',p.strength.priorities);for(const [n,k]of [['bench','benchKg'],['squat','squatKg'],['deadlift','deadliftKg'],['targetBench','targetBenchKg']])await fill(n,p.strength[k]?(p.strength[k]*2.2046226218).toFixed(1):'');}
  if(step==='availability'){await checks('trainingDays',p.days);await fill('minutes',p.minutes);await fill('time',p.preferredTime);await form().locator('[name=splits]').setChecked(!!p.splitSessions);}
  if(step==='equipment'){await checks('equipment',p.equipment);await select('cardio',p.cardioPreference||'walk');}
  if(step==='movement'){await checks('needs',p.capability.needs);await select('plyoEnabled',p.plyo.enabled?'yes':'no');await select('plyoExperience',p.plyo.experience);await select('landing',p.plyo.landing);await select('surface',p.plyo.surface);await form().locator('[name=impactPain]').setChecked(p.plyo.pain);}
  if(step==='capability'){await fill('balance',p.capability.balance);await fill('chairStands',p.capability.chairStands);await fill('walkMinutes',p.capability.walkMinutes);await fill('capabilityGoal',p.capability.goal);}
  if(step==='nutrition'){await select('nutritionGoal',p.nutrition.goal);await select('activity',p.nutrition.activity);await select('diet',p.nutrition.diet);await select('budget',p.nutrition.budget);await form().locator('[name=manualNutrition]').setChecked(!!p.nutrition.manualOnly);}
  if(step==='preferences'){await fill('allergies',p.nutrition.allergies.join(', '));await fill('dislikes',p.nutrition.dislikes.join(', '));await fill('likes',(p.nutrition.likes||[]).join(', '));}
  await form().locator('[type=submit]').click();
  if(await form().count()){const error=await form().locator('[role=alert]').textContent();a.equal(error,'',step+': '+error);a.notEqual(await form().getAttribute('data-onboard-step'),step,'Failed to advance from '+step);}
 }
 a.equal(await form().count(),0,'Onboarding finished');return steps;
}
module.exports={completeOnboarding};
