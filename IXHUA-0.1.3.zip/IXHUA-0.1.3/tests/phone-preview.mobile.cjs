/* Actual paired preview and real persisted onboarding, repeated in one browser.
   Mobile emulation is never a claim of physical iPhone validation. */
'use strict';
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path');
const {spawn}=require('node:child_process'),http=require('node:http'),a=require('node:assert/strict');
const {personas}=require('./athlete-fixtures.cjs'),{completeOnboarding}=require('./athlete-browser-helpers.cjs');
const root=path.resolve(__dirname,'..'),out=path.join(root,'test-results/owner');
const dataKey='rebuild-core-0-9';
async function run(){
 let child,browser;
 fs.mkdirSync(out,{recursive:true});
 const report={result:'RUNNING',scope:'Athlete Identity owner acceptance preview',personas:[],errors:[],failedResponses:[],physicalIPhone:'AWAITING OWNER TEST',nativeValidation:'NOT CLAIMED'};
 try{
  const reserve=http.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));const port=reserve.address().port;await new Promise(r=>reserve.close(r));
  const base=`http://127.0.0.1:${port}`;
  child=spawn(process.execPath,['scripts/start-ixhua.cjs','--no-open'],{cwd:root,env:{...process.env,IXHUA_PREVIEW_PORT:String(port),IXHUA_PREVIEW_ADDRESS:'',IXHUA_PREVIEW_TLS_CERT:'',IXHUA_PREVIEW_TLS_KEY:'',OPENAI_API_KEY:'',IXHUA_AI_MODEL:'',REBUILD_AI_MODEL:'',OFF_USER_AGENT:''},stdio:['ignore','pipe','pipe']});
  let output='';
  await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('Startup timed out: '+output)),12000);
   const receive=buf=>{output+=buf;if(output.includes('Press Ctrl+C to stop')){clearTimeout(timer);resolve();}};
   child.stdout.on('data',receive);child.stderr.on('data',receive);child.once('error',reject);child.once('exit',code=>{if(!output.includes('Press Ctrl+C to stop')){clearTimeout(timer);reject(Error('Startup exited '+code+': '+output));}});
  });
  report.launcher='PASS';
  const health=await(await fetch(base+'/preview/health')).json();report.sourceIdentity=health.sourceIdentity;report.buildId=health.buildId;
  browser=await chromium.launch(require('./browser-runtime.cjs').launchOptions());
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,reducedMotion:'reduce',acceptDownloads:true});
  // Exercise the actual LAN-compatible ID path, even though this automated client is local.
  await context.addInitScript(()=>Object.defineProperty(crypto,'randomUUID',{value:undefined}));
  const page=await context.newPage();page.setDefaultTimeout(12000);
  page.on('pageerror',e=>report.errors.push(e.message));page.on('response',r=>{if(r.status()>=400)report.failedResponses.push([r.status(),r.url()]);});
  await page.goto(base+'/owner-preview');await page.screenshot({path:path.join(out,'computer-launcher.png'),fullPage:true});
  a.ok((await page.locator('body').innerText()).includes('Athlete Identity'));
  await page.getByRole('link',{name:'Open the same app on this computer'}).click();await page.waitForURL(base+'/');
  a.equal(new URL(page.url()).hash,'');
  await page.locator('#ix-onboarding-form').waitFor();
  const cookies=await context.cookies();a.ok(cookies.some(x=>x.name==='ixhua_preview'&&x.httpOnly&&x.sameSite==='Strict'));
  const openControls=async()=>{
   const inOnboarding=page.locator('.ixhua-owner-onboarding');
   if(await inOnboarding.count())await inOnboarding.click();else await page.locator('.ixhua-preview-banner').click();
   await page.locator('#ixhua-phone-review').waitFor();
  };
  const reset=async()=>{
   await page.locator('#ixhua-owner-fresh').click();
   const navigation=page.waitForEvent('load');await page.locator('#ixhua-owner-reset-confirm').click();await navigation;
   await page.locator('#ix-onboarding-form[data-onboard-step=identity]').waitFor();
   a.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('rebuild-core-0-9')).athlete),undefined);
  };
  const state=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('rebuild-core-0-9')));
  await page.evaluate(()=>{localStorage.setItem('owner-unrelated-test','must survive reset');localStorage.setItem('rebuild-core-0-8',JSON.stringify({legacySentinel:'must not be reimported'}));});
  // A partially answered onboarding can be cancelled/reset without finishing it.
  await page.locator('[data-identity=strength]').click();await openControls();
  for(const value of await page.locator('[data-review-check]').evaluateAll(nodes=>nodes.map(n=>n.value)))a.equal(value,'NOT RUN');
  const beforeCancel=await state();await page.locator('#ixhua-owner-fresh').click();await page.locator('#ixhua-owner-reset-cancel').click();a.deepEqual(await state(),beforeCancel);
  await reset();a.equal((await state()).legacySentinel,undefined);report.draftResetAndCancel='PASS';
  const signatures=[];
  for(const id of ['A','D','E','F','G','H']){
   const p=personas[id],steps=await completeOnboarding(page,p,{reloadDraft:id==='A'}),st=await state();
   a.equal(st.athlete.primary,p.primary);a.ok(st.trainingPlan.length>0);
   a.equal(await page.locator('[data-today-priority]').getAttribute('data-today-priority'),p.primary);
   if(id==='A'){a.equal(st.athlete.running.benchmarkSeconds,555);a.equal(st.athlete.strength.experience,'experienced');}
   const nav=async name=>page.locator('#mobileNav [data-nav='+name+']').click();
   for(const screen of ['today','training','progress','plan']){
    await nav(screen);a.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),p.primary+' '+screen+' portrait overflow');
    if(screen==='training')a.equal(await page.locator('[data-training-priority]').getAttribute('data-training-priority'),({runner:'running',strength:'strength',hybrid:'hybrid',general:'overview',longevity:'capability',custom:'cardio'})[p.primary]);
    if(screen==='plan')a.equal(await page.locator('[data-plan-priority]').getAttribute('data-plan-priority'),p.primary);
    await page.screenshot({path:path.join(out,p.primary+'-'+screen+'.png'),fullPage:true,animations:'disabled'});
   }
   await page.reload();a.deepEqual((await state()).athlete,st.athlete);a.deepEqual((await state()).trainingPlan,st.trainingPlan);
   signatures.push(JSON.stringify(st.trainingPlan.map(x=>({type:x.type,title:x.title,prescription:x.prescription}))));
   await page.setViewportSize({width:844,height:390});a.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),p.primary+' landscape overflow');await page.setViewportSize({width:390,height:844});
   await openControls();
   if(id==='A'){
    await page.locator('[data-review-check=runner]').selectOption('PASS');await page.locator('[name=notes]').fill('Automated browser fixture only; physical iPhone checks remain pending.');
    a.equal((await page.evaluate(()=>JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k=>k.startsWith('ixhua-owner-phone-review:')))))).physicalPhone,false);
   }else a.equal(await page.locator('[data-review-check=runner]').inputValue(),'PASS','Feedback survives reset');
   const downloadPromise=page.waitForEvent('download');await page.locator('#ixhua-owner-export-data').click();const downloaded=await downloadPromise;
   a.deepEqual(JSON.parse(fs.readFileSync(await downloaded.path(),'utf8')).trainingPlan,st.trainingPlan,'Export contains actual program');
   await reset();
   const backup=await page.evaluate(()=>JSON.parse(localStorage.getItem('ixhua-owner-previous-round')));
   a.deepEqual(JSON.parse(backup.data).athlete,st.athlete);a.deepEqual(JSON.parse(backup.data).trainingPlan,st.trainingPlan);
   a.equal(await page.evaluate(()=>localStorage.getItem('owner-unrelated-test')),'must survive reset');
   a.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('rebuild-core-0-8')).legacySentinel),'must not be reimported');
   report.personas.push({identity:p.primary,steps,appointments:st.trainingPlan.length,profileAndPlanReload:'PASS',allFourSurfaces:'PASS',exportAndFreshReset:'PASS',previousRoundBackup:'PASS'});
  }
  a.equal(new Set(signatures).size,6,'Distinct real program contents, not just renamed headings');
  await openControls();
  a.equal(await page.locator('[data-review-check=runner]').inputValue(),'PASS');
  const downloadPromise=page.waitForEvent('download');await page.locator('#ixhua-owner-export-previous').click();const lastDownload=await downloadPromise;
  a.equal(JSON.parse(fs.readFileSync(await lastDownload.path(),'utf8')).athlete.primary,'custom');
  await page.screenshot({path:path.join(out,'owner-controls.png'),fullPage:true});
  await page.locator('[data-review-check=custom]').selectOption('BLOCKED');
  const feedbackPromise=page.waitForEvent('download');await page.locator('#ixhua-review-export').click();const feedbackDownload=await feedbackPromise;
  const feedback=JSON.parse(fs.readFileSync(await feedbackDownload.path(),'utf8'));a.equal(feedback.results.runner,'PASS');a.equal(feedback.results.custom,'BLOCKED');a.equal(feedback.physicalPhone,false);a.equal(feedback.buildId,report.buildId);
  report.feedbackExport='PASS';a.deepEqual(report.errors,[]);a.deepEqual(report.failedResponses,[]);report.result='PASS';
 }catch(error){report.result='FAIL';report.failure=error.stack;throw error;}
 finally{
  report.timestamp=new Date().toISOString();fs.writeFileSync(path.join(out,'owner-mobile.json'),JSON.stringify(report,null,2)+'\n');
  if(browser)await browser.close();if(child&&child.exitCode===null){const exited=new Promise(r=>child.once('exit',r));child.kill('SIGTERM');await exited;}
 }
 console.log('PASS: actual paired preview, six identities, draft reset/cancel, all four surfaces, reload, exports, saved feedback and isolated reset. Physical iPhone: awaiting owner.');
}
run().catch(error=>{console.error(error.stack);process.exitCode=1;});
