const C=require('../js/ixhua/core');
const equipment=['bodyweight','barbell','dumbbells','cables','machines','pullup bar'];
const base={age:30,heightCm:180,weightKg:80,sex:'male',equipment,startedOn:'2026-09-14'};
const personas={
 A:C.normalProfile({...base,primary:'runner',days:[1,3,5],running:{goal:'first5k',experience:'new',days:3},strength:{experience:'experienced',days:2}}),
 B:C.normalProfile({...base,primary:'runner',days:[1,2,3,4,5,6],minutes:60,running:{goal:'faster5k',experience:'experienced',days:6,currentDays:6,weeklyMinutes:300,longDay:6,continuousMinutes:60,consistentWeeks:20,targetSeconds:1200},strength:{days:2,experience:'some'}}),
 C:C.normalProfile({...base,primary:'strength',days:[1,3,5],strength:{experience:'new',days:3}}),
 D:C.normalProfile({...base,primary:'strength',days:[1,2,3,4,5],minutes:75,strength:{experience:'experienced',goal:'muscle',days:5,priorities:['arms']}}),
 E:C.normalProfile({...base,primary:'hybrid',days:[1,2,3,4,5,6],minutes:60,hybridPriority:'equal',running:{goal:'faster5k',experience:'experienced',days:3,currentDays:3,weeklyMinutes:120,continuousMinutes:40,consistentWeeks:12,targetSeconds:1500},strength:{experience:'experienced',days:3,benchKg:85,targetBenchKg:102.058}}),
 F:C.normalProfile({...base,primary:'general',days:[1,2,4,6],cardioPreference:'bike',strength:{days:2}}),
 G:C.normalProfile({...base,age:60,primary:'longevity',days:[1,2,3,4,5,6],strength:{experience:'experienced',days:2},capability:{balance:25,chairStands:16,walkMinutes:60,goal:'Keep hiking'}}),
 H:C.normalProfile({...base,primary:'custom',days:[1,3,5],secondary:['cardio','mobility','balance']})
};
module.exports={personas};
