const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const C=require('../js/ixhua/core');
const T=require('../js/ixhua/training');

const fullEquipment=['bodyweight','dumbbells','barbell','cables','machines','bands','pullup bar','sliders'];
function hybridStrength(overrides={}){
 return C.normalProfile({primary:'hybrid',hybridPriority:'equal',days:[1,2,3,4,5,6],minutes:70,equipment:fullEquipment,running:{days:2,currentDays:2,weeklyMinutes:80,continuousMinutes:30,consistentWeeks:8,experience:'some'},strength:{experience:'some',days:4,currentDays:4,consistentWeeks:12,breakWeeks:0,goal:'muscle',split:'upperlower'},...overrides});
}

test('Some-experience Upper/Lower sessions keep REBUILD-level depth without flattening to two sets',()=>{
 const p=hybridStrength();
 const upper=T.strength(p,0,[],{volumeMode:'hybrid-equal'});
 const lower=T.strength(p,1,[],{volumeMode:'hybrid-equal'});
 assert.equal(upper.exercises.length,7);
 assert.equal(lower.exercises.length,6);
 assert.deepEqual(upper.exercises.map(x=>x.plannedSets),[4,4,3,3,3,3,3]);
 assert.deepEqual(lower.exercises.map(x=>x.plannedSets),[4,4,3,3,3,3]);
 assert.ok(upper.minutes>=55);
 assert.ok(lower.minutes>=50);
});

test('Some-experience re-entry preserves a deep exercise menu and never collapses every movement to two sets',()=>{
 const base=hybridStrength();
 const p=C.normalProfile({...base,strength:{...base.strength,consistentWeeks:0,breakWeeks:6}});
 const upper=T.strength(p,0,[],{volumeMode:'hybrid-equal'});
 assert.equal(upper.exercises.length,7);
 assert.ok(upper.exercises.every(x=>x.plannedSets>=3));
 assert.match(upper.reason,/experience is retained/i);
});

test('Today navigation closes stale sheets and resets the selected date before rendering Today',()=>{
 const src=fs.readFileSync(require.resolve('../js/app.js'),'utf8');
 const line=src.split(/\r?\n/).find(x=>x.startsWith('function setView(id)'));
 assert.ok(line,'setView source exists');
 assert.match(line,/dialog\[open\]/);
 assert.match(line,/id==='today'/);
 assert.match(line,/state\.selectedDate=todayKey/);
 let closed=0,rendered=0,navRendered=0,saved=0,scrolled=0;
 const state={view:'plan',selectedDate:'2026-10-01'};
 let currentView='plan',selectedDate='2026-10-01';
 const sandbox={
   document:{querySelectorAll:()=>[{close(){closed++;}}]},
   app:{dataset:{}},
   state,
   save:()=>saved++,renderNav:()=>navRendered++,render:()=>rendered++,
   window:{scrollTo:()=>scrolled++},
   Date:class extends Date{constructor(...a){super(...(a.length?a:['2026-09-14T12:00:00-07:00']));}}
 };
 vm.createContext(sandbox);
 vm.runInContext(`${line}; this.__setView=setView;`,sandbox);
 sandbox.__setView('today');
 assert.equal(closed,1);
 assert.equal(state.view,'today');
 assert.equal(state.selectedDate,'2026-09-14');
 assert.equal(rendered,1);assert.equal(navRendered,1);assert.equal(saved,1);assert.equal(scrolled,1);
});

test('Hybrid planner never stacks two core/key sessions or two strength sessions on the same date',()=>{
 const p=hybridStrength({splitSessions:true,days:[1,2,3,4,5,6],running:{days:2,currentDays:2,weeklyMinutes:80,continuousMinutes:30,consistentWeeks:8,experience:'some'},strength:{experience:'some',days:4,currentDays:4,consistentWeeks:12,breakWeeks:0,goal:'muscle',split:'upperlower'}});
 const plan=T.buildPlan(p,[],[],'2026-09-14',1).sessions;
 const byDate=new Map();
 for(const s of plan){if(!byDate.has(s.date))byDate.set(s.date,[]);byDate.get(s.date).push(s);}
 for(const [date,sessions] of byDate){
   assert.ok(sessions.filter(s=>s.type==='strength').length<=1,`${date} has more than one strength session: ${sessions.map(s=>s.title).join(', ')}`);
   if(sessions.some(s=>s.stress==='high')) assert.equal(sessions.filter(s=>s.priority==='key').length,1,`${date} stacks a core session on a high-demand day: ${sessions.map(s=>s.title).join(', ')}`);
 }
});

test('Hybrid Upper and Lower key sessions distribute to different days',()=>{
 const p=hybridStrength({splitSessions:true,days:[1,2,3,4,5,6],running:{days:2,currentDays:2,weeklyMinutes:80,continuousMinutes:30,consistentWeeks:8,experience:'some'},strength:{experience:'some',days:4,currentDays:4,consistentWeeks:12,breakWeeks:0,goal:'muscle',split:'upperlower'}});
 const plan=T.buildPlan(p,[],[],'2026-09-14',1).sessions;
 const strengths=plan.filter(s=>s.type==='strength');
 assert.ok(strengths.length>=2,'expected at least two strength sessions');
 assert.equal(new Set(strengths.map(s=>s.date)).size,strengths.length,'strength sessions must each occupy a different day');
});

test('Today navigation clears selected training state and marks the app as Today',()=>{
 const src=fs.readFileSync(require.resolve('../js/app.js'),'utf8');
 const line=src.split(/\r?\n/).find(x=>x.startsWith('function setView(id)'));
 assert.match(line,/state\.selectedTraining=null/);
 assert.match(line,/app\.dataset\.view=id/);
});

test('Hybrid combat conditioning creates a dedicated interval + core session without replacing running or strength',()=>{
 const p=hybridStrength({days:[1,2,3,4,5,6],minutes:75,splitSessions:true,running:{...hybridStrength().running,days:3,experience:'some',continuousMinutes:30,weeklyMinutes:90,consistentWeeks:8},strength:{...hybridStrength().strength,days:3,experience:'some',split:'upperlower',consistentWeeks:8},conditioning:{enabled:true,focus:'mma',days:1,experience:'some',modality:'airbike',core:true,recoveryMobility:true},plyo:{enabled:true,experience:'some',landing:'comfortable',surface:'rubber',pain:false}});
 const plan=T.buildPlan(p,[],[],C.addDays(C.monday(C.dateKey()),7),1),types=plan.sessions.map(s=>s.type),cc=plan.sessions.find(s=>s.methodology==='COMBAT_HIIT');
 assert.ok(types.includes('running'));assert.ok(types.includes('strength'));assert.ok(cc,'dedicated conditioning should be planned');assert.equal(cc.protocol.work,20);assert.equal(cc.protocol.easy,40);assert.equal(cc.protocol.reps,10);assert.ok(cc.exercises.some(e=>/Pallof|Side Plank|Hanging Knee|Farmer/.test(e.name)));
});

test('Combat conditioning is not mislabeled as Zone 2 and keeps hard-day collision rules',()=>{
 const p=hybridStrength({days:[1,2,3,4,5,6],minutes:75,splitSessions:true,running:{...hybridStrength().running,days:3,experience:'some',continuousMinutes:30,weeklyMinutes:90,consistentWeeks:8},strength:{...hybridStrength().strength,days:3,experience:'some',split:'upperlower',consistentWeeks:8},conditioning:{enabled:true,focus:'combat',days:1,experience:'some',modality:'airbike',core:true}});
 const plan=T.buildPlan(p,[],[],C.addDays(C.monday(C.dateKey()),7),1),cc=plan.sessions.find(s=>s.methodology==='COMBAT_HIIT');assert.ok(cc);assert.equal(cc.stress,'high');assert.doesNotMatch(cc.reason,/Zone 2/i);const same=plan.sessions.filter(s=>s.date===cc.date&&s.id!==cc.id);assert.ok(same.every(s=>s.type==='running'&&s.stress==='low'),'conditioning may only share a split day with an easy run');
});

test('Hybrid recovery mobility can occupy an otherwise open recovery day without replacing core training',()=>{
 const p=hybridStrength({days:[1,2,3,5,6],minutes:75,splitSessions:true,running:{...hybridStrength().running,days:2,experience:'some',continuousMinutes:30,weeklyMinutes:75,consistentWeeks:8},strength:{...hybridStrength().strength,days:2,experience:'some',split:'upperlower',consistentWeeks:8},conditioning:{enabled:true,focus:'mma',days:1,experience:'some',modality:'airbike',core:true,recoveryMobility:true},plyo:{enabled:true,experience:'some',landing:'comfortable',surface:'rubber',pain:false}});
 const plan=T.buildPlan(p,[],[],C.addDays(C.monday(C.dateKey()),7),1),rec=plan.sessions.find(s=>s.methodology==='RECOVERY_MOBILITY');
 assert.ok(rec,'recovery mobility should use an open day when explicitly requested');
 assert.equal(plan.sessions.filter(s=>s.date===rec.date&&s.priority==='key').length,0,'recovery mobility should not share a day with a key session');
});

test('Hybrid with dedicated conditioning turns duplicate run intensity into easy work unless Running leads',()=>{
 const p=hybridStrength({splitSessions:true,running:{...hybridStrength().running,goal:'faster5k',days:3,currentDays:3,weeklyMinutes:90,continuousMinutes:30,consistentWeeks:8,experience:'some'},strength:{...hybridStrength().strength,days:4,split:'upperlower'},conditioning:{enabled:true,focus:'mma',days:1,experience:'some',modality:'airbike',core:true,recoveryMobility:true}});
 const runs=T.demands(p,[],'2026-09-14').filter(s=>s.type==='running');
 assert.ok(runs.filter(s=>s.runKind==='easy').length>=2,'dedicated conditioning should keep at least two runs easy in equal Hybrid');
 assert.ok(!runs.some(s=>s.runKind==='interval'),'equal Hybrid should not duplicate HIIT with a running interval when dedicated conditioning is already present');
});

test('Easy runs can pair with weights while long runs keep their own day',()=>{
 const p=hybridStrength({splitSessions:true,days:[0,1,2,3,5,6],running:{...hybridStrength().running,goal:'faster5k',days:3,currentDays:3,weeklyMinutes:90,continuousMinutes:30,consistentWeeks:8,experience:'some',longDay:0,longMinutes:70},strength:{...hybridStrength().strength,days:4,split:'upperlower'},conditioning:{enabled:true,focus:'mma',days:1,experience:'some',modality:'airbike',core:true,recoveryMobility:true}});
 const g=T.buildPlan(p,[],[],'2026-09-14',1),plan=g.sessions;
 const paired=plan.filter(s=>s.type==='running'&&s.runKind==='easy').some(run=>plan.some(x=>x.type==='strength'&&x.date===run.date&&Math.abs(require('../js/ixhua/running').minutesOf(x.time)-require('../js/ixhua/running').minutesOf(run.time))>=180));
 assert.ok(paired,'at least one short easy run should share a day with strength when split sessions are allowed');
 const long=plan.find(s=>s.type==='running'&&s.runKind==='long');assert.ok(long,'long run exists');
 assert.equal(plan.filter(s=>s.date===long.date&&s.priority==='key').length,1,'long run owns its training day');
 assert.ok(plan.some(s=>s.methodology==='COMBAT_HIIT'),'freed schedule should preserve dedicated conditioning');
 assert.equal(g.unplaced.length,0,'the integrated example week should fit without deleting a core session');
});

test('Upper and Lower strength families always alternate chronologically',()=>{
 const p=hybridStrength({splitSessions:true,days:[0,1,2,3,5,6],running:{...hybridStrength().running,days:3,currentDays:3,weeklyMinutes:90,continuousMinutes:30,consistentWeeks:8},strength:{...hybridStrength().strength,days:4,split:'upperlower'},conditioning:{enabled:true,focus:'mma',days:1,experience:'some',modality:'airbike',core:true,recoveryMobility:true}});
 const strengths=T.buildPlan(p,[],[],'2026-09-14',4).sessions.filter(s=>T.strengthFamily(s)).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
 assert.ok(strengths.length>=8);
 for(let i=1;i<strengths.length;i++)assert.notEqual(T.strengthFamily(strengths[i]),T.strengthFamily(strengths[i-1]),`${strengths[i-1].title} cannot be followed by ${strengths[i].title}`);
});

test('Week personalization and compact date formatting are wired into the real athlete UI',()=>{
 const src=fs.readFileSync(require.resolve('../js/ixhua/athlete-ui'),'utf8');
 assert.match(src,/Personalize this week/);
 assert.match(src,/userScheduled:true/);
 assert.match(src,/compactDate/);
 assert.match(src,/easy run \(45 min or less\).*strength or dedicated conditioning/i);
 assert.doesNotMatch(src,/CURRENT UPCOMING[\s\S]{0,400}esc\(s\.date\)/);
});
