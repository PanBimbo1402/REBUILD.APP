/* Reuse the pinned, already-cached test browser. No network download. */
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib');
function launchOptions(){const executablePath=process.env.IXHUA_TEST_CHROMIUM;if(!executablePath)return {headless:true};
 // Work recovery can truncate large transient executables. Restore from the
 // checked package cache atomically, rather than trying a broken executable.
 if(fs.existsSync(executablePath)&&fs.statSync(executablePath).size!==209022176){
  const pkg=require.resolve('@sparticuz/chromium'),root=path.resolve(path.dirname(pkg),'..'),archive=path.join(root,'bin/chromium.br');
  const bytes=zlib.brotliDecompressSync(fs.readFileSync(archive));if(bytes.length!==209022176)throw Error('Unexpected cached Chromium version; update the pinned test-runtime manifest explicitly.');
  fs.writeFileSync(executablePath+'.restore',bytes,{mode:0o700});fs.renameSync(executablePath+'.restore',executablePath);
 }
 return {headless:true,executablePath,args:['--single-process','--no-zygote','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']};
}
module.exports={launchOptions};
