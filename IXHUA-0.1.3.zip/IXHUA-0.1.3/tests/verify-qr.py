"""Decode perfect SVG QR symbols with independent ReportLab layout/RS tables.

Requires Python 3 and reportlab for this optional developer verification only.
This is a payload check, not an optical/physical-iPhone scan or error-correction test.
"""
import json
import re
import subprocess
from pathlib import Path
from reportlab.graphics.barcode import qrencoder as independent

ROOT = Path(__file__).resolve().parents[1]


def decode(svg):
    size = int(re.search(r'viewBox="0 0 (\d+) \d+"', svg).group(1)) - 8
    version = (size - 17) // 4
    assert 1 <= version <= 40 and size == version * 4 + 17
    matrix = [[False] * size for _ in range(size)]
    for col, row in re.findall(r'M(\d+),(\d+)h1v1h-1z', svg):
        row, col = int(row) - 4, int(col) - 4
        assert 0 <= row < size and 0 <= col < size, 'Four-module quiet zone was violated'
        matrix[row][col] = True
    info = 0
    for bit in range(15):
        row = bit if bit < 6 else bit + 1 if bit < 8 else size - 15 + bit
        info |= int(matrix[row][8]) << bit
    candidates = [v for v in range(32) if independent.QRUtil.getBCHTypeInfo(v) == info]
    assert len(candidates) == 1, 'Invalid QR format bits'
    level, pattern = candidates[0] >> 3, candidates[0] & 7
    assert level == independent.QRErrorCorrectLevel.M
    layout = independent.QRCode(version, level)
    layout.moduleCount = size
    mask = independent.QRUtil.getMask(pattern)
    bits = [int(matrix[row][col] ^ mask(row, col)) for col, row in layout.dataPosIterator()]
    blocks = independent.QRRSBlock.getRSBlocks(version, level)
    count = sum(block.totalCount for block in blocks)
    interleaved = [sum(bits[i * 8 + j] << (7 - j) for j in range(8)) for i in range(count)]
    data = [[] for _ in blocks]
    cursor = 0
    for i in range(max(block.dataCount for block in blocks)):
        for block_number, block in enumerate(blocks):
            if i < block.dataCount:
                data[block_number].append(interleaved[cursor])
                cursor += 1
    stream = ''.join(f'{byte:08b}' for block in data for byte in block)
    assert int(stream[:4], 2) == 4, 'Expected byte mode'
    width = 8 if version < 10 else 16
    length = int(stream[4:4 + width], 2)
    payload = stream[4 + width:4 + width + length * 8]
    assert len(payload) == length * 8
    return bytes(int(payload[i:i + 8], 2) for i in range(0, len(payload), 8)).decode('ascii'), version


vectors = [
    f'{scheme}://{host}:{port}/pair#access={"aZ0_" * 8}&build={"0123456789abcdef" * 4}'
    for scheme, host, port in [
        ('http', '10.0.0.2', 4318),
        ('http', '192.168.255.254', 65535),
        ('http', '172.16.0.12', 1024),
        ('http', '127.0.0.1', 4318),
        ('https', '192.168.1.20', 4318),
    ]
]
result = subprocess.run(
    ['node', '-e', "const fs=require('fs'),{qrSvg}=require('./server/phone-preview.cjs');process.stdout.write(JSON.stringify(JSON.parse(fs.readFileSync(0,'utf8')).map(qrSvg)))"],
    input=json.dumps(vectors), text=True, capture_output=True, check=True, cwd=ROOT,
)
versions = []
for expected, svg in zip(vectors, json.loads(result.stdout), strict=True):
    actual, version = decode(svg)
    assert actual == expected, 'QR decoded to a different URL'
    versions.append(version)
report = {'result': 'PASS', 'payloadVectors': len(vectors), 'qrVersions': versions,
          'independentDecoder': 'ReportLab QR layout/RS tables plus payload decoder',
          'physicalCameraScan': 'NOT TESTED', 'errorCorrectionUnderImageDamage': 'NOT TESTED'}
(ROOT / 'test-results').mkdir(exist_ok=True)
(ROOT / 'test-results' / 'qr-payload.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
