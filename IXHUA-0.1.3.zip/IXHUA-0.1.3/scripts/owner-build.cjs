'use strict';
// Archive receipt for the actual app and launcher. No Git installation is needed to verify it.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const sourcePaths=['index.html','manifest.json','package.json','build.cjs','js','css','assets','server','scripts','config','START-IXHUA.bat','START-IXHUA.command'];
function inventory(root){
  const files={};
  function visit(relative){
    const file=path.join(root,relative),stat=fs.lstatSync(file);
    if(stat.isSymbolicLink())throw Error('Unexpected symbolic link in owner source: '+relative);
    if(stat.isDirectory())fs.readdirSync(file).sort().forEach(name=>visit(relative+'/'+name));
    else files[relative]=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  }
  sourcePaths.forEach(visit);return files;
}
function inspect(root){
  const receipt=path.join(root,'BUILD-IDENTITY.json');
  if(!fs.existsSync(receipt))return {verified:false,commit:null,status:'DEVELOPMENT WORKING COPY',detail:'No packaged-source receipt. This copy has not been sealed for owner delivery.'};
  try{
    const value=JSON.parse(fs.readFileSync(receipt,'utf8'));
    const config=JSON.parse(fs.readFileSync(path.join(root,'config/phone-preview.json'),'utf8'));
    if(value.schema!==1||value.baselineCommit!==config.ownerAcceptance.baselineCommit||!/^[a-f0-9]{40}$/.test(value.commit))throw Error('Invalid source receipt.');
    const actual=inventory(root),expected=value.files||{};
    if(Object.keys(actual).length!==Object.keys(expected).length||Object.keys(actual).some(file=>actual[file]!==expected[file]))throw Error('Application or launcher files differ from the packaged commit.');
    return {verified:true,commit:value.commit,baselineCommit:value.baselineCommit,status:'PACKAGED SOURCE VERIFIED',detail:'Application and launcher bytes match BUILD-IDENTITY.json.'};
  }catch(error){return {verified:false,commit:null,status:'SOURCE VERIFICATION FAILED',detail:error.message};}
}
function seal(root){
  const git=(...args)=>execFileSync('git',['-C',root,...args],{encoding:'utf8'}).trim();
  const config=JSON.parse(fs.readFileSync(path.join(root,'config/phone-preview.json'),'utf8'));
  const baselineCommit=config.ownerAcceptance.baselineCommit;
  git('merge-base','--is-ancestor',baselineCommit,'HEAD');
  git('diff','--quiet','HEAD','--');
  const untracked=git('ls-files','--others','--exclude-standard').split('\n').filter(Boolean).filter(x=>sourcePaths.some(p=>x===p||x.startsWith(p+'/')));
  if(untracked.length)throw Error('Commit source files before sealing: '+untracked.join(', '));
  const receipt={schema:1,kind:'IXHUA ATHLETE IDENTITY OWNER ACCEPTANCE',commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),baselineCommit,files:inventory(root)};
  fs.writeFileSync(path.join(root,'BUILD-IDENTITY.json'),JSON.stringify(receipt,null,2)+'\n');
  return inspect(root);
}
if(require.main===module){
  try{
    const root=path.resolve(__dirname,'..'),result=process.argv.includes('--seal')?seal(root):inspect(root);
    console.log(JSON.stringify(result,null,2));if(!result.verified)process.exitCode=1;
  }catch(error){console.error(error.message);process.exitCode=1;}
}
module.exports={inventory,inspect,seal};
