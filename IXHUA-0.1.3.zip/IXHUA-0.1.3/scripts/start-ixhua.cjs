'use strict';
const path=require('node:path');
const fs=require('node:fs');
const {spawn,spawnSync}=require('node:child_process');
const {lanAddresses}=require('./preview-network.cjs');
const root=path.resolve(__dirname,'..');

async function main() {
  if(Number(process.versions.node.split('.')[0])<22) throw new Error('Node.js 22+ is required. Install the LTS Windows installer at https://nodejs.org/en/download and restart START-IXHUA.');
  process.chdir(root);
  if(fs.existsSync(path.join(root,'.env'))) process.loadEnvFile(path.join(root,'.env'));
  for(const file of ['index.html','js/app.js','js/premium-source.js','js/engine.js','js/platform.js','config/phone-preview.json','scripts/vendor/qrcode-terminal/vendor/QRCode/index.js']) {
    if(!fs.existsSync(path.join(root,file))) throw new Error(`Required project file missing: ${file}. Extract the complete ZIP, then start again.`);
  }
  console.log('IXHUA 0.1.3 · owner acceptance\nChecking and building the verified application…');
  const build=spawnSync(process.execPath,['build.cjs'],{cwd:root,encoding:'utf8'});
  if(build.status!==0) throw new Error(`The app build failed. ${build.stderr||build.error?.message||''}`);
  const config=JSON.parse(fs.readFileSync(path.join(root,'config/phone-preview.json'),'utf8'));
  const identity=require('./owner-build.cjs').inspect(root);
  if(identity.status==='SOURCE VERIFICATION FAILED')throw new Error(identity.detail+' Extract a fresh copy of the owner ZIP.');
  const port=Number(process.env.IXHUA_PREVIEW_PORT||config.defaultPort);
  if(!Number.isInteger(port)||port<1024||port>65535) throw new Error('IXHUA_PREVIEW_PORT must be an integer from 1024 to 65535.');
  let addresses;
  try { addresses=lanAddresses(); }
  catch { addresses=[];console.log('Network adapter discovery is unavailable in this environment. The phone QR is blocked here; computer preview can still run.'); }
  if(process.env.IXHUA_PREVIEW_ADDRESS) {
    const index=addresses.findIndex(a=>a.address===process.env.IXHUA_PREVIEW_ADDRESS);
    if(index<0) throw new Error('IXHUA_PREVIEW_ADDRESS must match a private IPv4 address on this computer. Remove the override to detect Wi-Fi automatically.');
    addresses.unshift(addresses.splice(index,1)[0]);
  }
  const certFile=process.env.IXHUA_PREVIEW_TLS_CERT,keyFile=process.env.IXHUA_PREVIEW_TLS_KEY;
  if(Boolean(certFile)!==Boolean(keyFile)) throw new Error('HTTPS requires both IXHUA_PREVIEW_TLS_CERT and IXHUA_PREVIEW_TLS_KEY.');
  const tls=certFile?{cert:fs.readFileSync(path.resolve(root,certFile)),key:fs.readFileSync(path.resolve(root,keyFile))}:undefined;
  const protocol=tls?'https':'http';
  const {createPhonePreview}=require('../server/phone-preview.cjs');
  const {createServer}=require('../server/index.cjs');
  const preview=createPhonePreview({addresses,port,protocol});
  const server=createServer({preview,tls});
  server.requestTimeout=60000;
  server.headersTimeout=15000;
  await new Promise((resolve,reject)=>{
    server.once('error',reject);
    server.listen(port,'0.0.0.0',resolve);
  }).catch(error=>{
    if(error.code==='EADDRINUSE') throw new Error(`Port ${port} is already in use. Close the previous START-IXHUA window, then retry. No other service was stopped. If it belongs to another app, set IXHUA_PREVIEW_PORT to a free port in .env; a new port has separate browser data.`);
    throw error;
  });
  let stopping=false;
  function stop() {
    if(stopping)return;stopping=true;
    console.log('\nStopping IXHUA preview and backend…');
    server.close(()=>process.exit(0));
    server.closeAllConnections();
  }
  process.once('SIGINT',stop);process.once('SIGTERM',stop);
  try {
    // Loopback probe uses the current process certificate as its local trust anchor.
    const health=await new Promise((resolve,reject)=>{
      const transport=require(tls?'node:https':'node:http');
      const request=transport.get({hostname:'127.0.0.1',port,path:'/preview/health',...(tls?{ca:tls.cert,servername:process.env.IXHUA_PREVIEW_TLS_SERVERNAME||'localhost'}:{})},response=>{
        let body='';response.on('data',chunk=>body+=chunk);response.on('end',()=>{
          try {if(response.statusCode!==200)throw new Error('Health endpoint failed.');resolve(JSON.parse(body));} catch(error){reject(error);}
        });
      });request.setTimeout(5000,()=>request.destroy(new Error('Startup readiness check timed out.')));request.on('error',reject);
    });
    if(health.nonce!==preview.nonce||health.buildId!==preview.buildId||!health.ready) throw new Error('The preview readiness check did not match this build.');
  } catch(error) {server.close();server.closeAllConnections();throw error;}
  const dashboard=`${protocol}://127.0.0.1:${port}/owner-preview`;
  console.log(`App + backend: RUNNING\nSource: ${config.sourceProduct}\nCheckpoint: ${config.ownerAcceptance.baselineCommit.slice(0,12)}\nOwner source: ${identity.commit||identity.status}\nBuild: ${preview.buildId.slice(0,12)}\nQR and instructions: ${dashboard}`);
  if(addresses.length) {
    console.log(`\nConnect iPhone and computer to the same trusted Wi-Fi.\nScan this QR with iPhone Camera, tap the link, and open Safari.\nNetwork: ${addresses[0].name} (${addresses[0].address})`);
    if(process.stdout.isTTY) require('./vendor/qrcode-terminal').generate(preview.makeLink(addresses[0].address),{small:true});
    console.log('A large, camera-friendly QR is displayed on the browser page.');
  } else console.log('PHONE PREVIEW BLOCKED: No private network address. Connect Wi-Fi/Ethernet and restart. Computer preview remains available.');
  console.log(`${tls?'HTTPS':'HTTP on trusted LAN only; not encrypted'}. Use test data.\nOwner acceptance: IXHUA 0.1.3. Full RC and Native Device Beta are separate gates.\nIn the app: Owner testing > Start fresh test to repeat onboarding.\nKeep this window open and the computer awake. Press Ctrl+C to stop all preview services.`);
  if(!process.argv.includes('--no-open')) {
    const command=process.platform==='win32'?'rundll32':process.platform==='darwin'?'open':'xdg-open';
    const args=process.platform==='win32'?['url.dll,FileProtocolHandler',dashboard]:[dashboard];
    const child=spawn(command,args,{stdio:'ignore',windowsHide:true});
    child.once('error',()=>console.log(`Open this address manually in your computer browser: ${dashboard}`));child.unref();
  }
}
main().catch(error=>{console.error(`\nSTART-IXHUA could not start: ${error.message}`);process.exitCode=1;});
