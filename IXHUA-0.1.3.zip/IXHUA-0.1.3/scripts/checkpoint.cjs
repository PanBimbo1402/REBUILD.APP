'use strict';
// Explicit recovery checkpoints; never pushes, deploys, or labels a release complete.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const name=process.argv[2];if(!/^\d{2}-[a-z0-9-]+$/.test(name||''))throw Error('Use a checkpoint name such as 01-running.');
const root=path.resolve(__dirname,'..'),dest=path.resolve(root,'../checkpoints');fs.mkdirSync(dest,{recursive:true});
const run=(command,args,cwd=root)=>cp.execFileSync(command,args,{cwd,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
run('git',['diff','--check']);run('git',['add','.']);run('git',['commit','-m',`checkpoint: ${name} tested IXHUA vertical slice`]);
const commit=run('git',['rev-parse','HEAD']),bundle=path.join(dest,`IXHUA-RECOVERY-${name}.bundle`);
run('git',['bundle','create',bundle,'--all']);const verification=run('git',['bundle','verify',bundle]);
const recover=path.join(dest,`verify-${name}`);if(fs.existsSync(recover))throw Error('Recovery verification directory already exists. Choose a new checkpoint name.');
run('git',['clone',bundle,recover],dest);if(run('git',['rev-parse','HEAD'],recover)!==commit)throw Error('Recovered commit differs from source.');
run('git',['fsck','--no-dangling'],recover);
const criticalTests=[];
const testEnv={...process.env,NODE_PATH:path.join(root,'node_modules')};
for(const args of [['build.cjs'],['--test','tests/engine.test.cjs','tests/phone-preview.test.cjs','tests/ixhua-running.test.cjs','tests/ixhua-athlete.test.cjs'],['tests/ixhua-running.mobile.cjs'],['tests/ixhua-athlete.mobile.cjs']]){
 console.log('Recovered clone verification:',args.join(' '));
 const result=cp.spawnSync(process.execPath,args,{cwd:recover,env:testEnv,encoding:'utf8',timeout:300000});
 const output=(result.stdout||'')+(result.stderr||'');
 const log=path.join(dest,`IXHUA-RECOVERY-${name}-${criticalTests.length+1}.txt`);fs.writeFileSync(log,output);
 if(result.status!==0)throw Error('Recovered clone failed: '+args.join(' ')+'; see '+log+' '+(result.error||''));
 criticalTests.push({command:'node '+args.join(' '),status:'PASS',log});
}
const changed=run('git',['diff','--name-only'],recover).split('\n').filter(Boolean).filter(p=>!p.startsWith('verification/')&&!p.startsWith('test-results/'));
if(changed.length)throw Error('Recovery checks unexpectedly changed source: '+changed.join(', '));
fs.writeFileSync(path.join(dest,`IXHUA-RECOVERY-${name}.json`),JSON.stringify({kind:'RECOVERY CHECKPOINT — NOT A RELEASE CANDIDATE',commit,bundle,verifiedClone:recover,verifiedAt:new Date().toISOString(),verification,criticalTests,sourceUnchangedAfterTests:true},null,2));
console.log(JSON.stringify({commit,bundle,recoveredCommit:run('git',['rev-parse','HEAD'],recover),recoverable:true}));
