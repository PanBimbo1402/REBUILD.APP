"""Restore the source-linked matrix from the existing audit/reconstruction record.
This enumerates source requirements; it does not re-audit or re-interpret them.
Status is evidence-driven and never inferred from filenames alone.
"""
from pathlib import Path
import re,csv,json,hashlib
root=Path(__file__).resolve().parents[1]
source=root/'docs/IXHUA-SOURCE-OF-TRUTH.txt'
lines=source.read_text().splitlines()
headings=[(0,'Execution Control Layer')]+[(i,re.sub(r'^\s*(?:#+\s*)?\d+\.\s*','',s).strip()) for i,s in enumerate(lines) if re.match(r'^\s*(?:#+\s*)?\d+\.\s+[A-Z]',s)]
evidence_path=root/'verification/ixhua/requirement-evidence.json'
evidence=json.loads(evidence_path.read_text()) if evidence_path.exists() else {}
rows={}
for j,(index,title) in enumerate(headings):
    end=headings[j+1][0] if j+1<len(headings) else len(lines)
    key=re.sub(r'[^A-Z0-9]+','-',title.upper()).strip('-')
    domain=next((d for d,pat in [('Running','RUN|RACE|MARATHON|5K|10K'),('Strength','STRENGTH|HYPERTROPHY|SPLIT|ARM|MUSCLE PRIOR'),('Adaptation','ADAPT|SCHEDULE|CALENDAR|SHIFT|CONFLICT|WORK|SCHOOL|LIFE|LEARN'),('Nutrition','NUTRITION|FOOD|SCAN|FUEL|PROTEIN'),('Anatomy','3D|ANATOMY|ANIMATION|MEDIA|MAPPING'),('Plyometrics','PLYO|POWER'),('Identity','IDENTITY|ONBOARD|PROFILE|PERSONA'),('Native','WATCH|NATIVE|HEALTHKIT|HEALTH CONNECT|WEAR|NOTIFICATION|GPS'),('Research','RESEARCH|EVIDENCE|STUD|SCIENCE|METHODOLOGY'),('Verification','TEST|GATE|DELIVERY|ACCEPTANCE|SECURITY|STATUS')] if re.search(pat,title)), 'Product')
    section=f'IXHUA-SOURCE-OF-TRUTH.txt:{index+1}'
    if key in rows:
        rows[key]['Source section']+='; '+section
        continue
    ev=evidence.get(key,{})
    rows[key]={'Requirement ID':'IX-'+str(len(rows)+1).zfill(3),'Domain':domain,'Source section':section,'Requirement':title,'Existing implementation':ev.get('existing','Prior audit and interrupted-run reconstruction record; working 0.9 foundation preserved at 181a324.'),'Required change':'Implement and connect the complete source section; repeated sections use the stricter requirement.','Files/components affected':ev.get('files',''),'Dependencies':ev.get('dependencies','See source section and docs/IMPLEMENTATION-DEPENDENCIES.md'),'Test required':ev.get('test','Data → engine → UI → save → reload → adaptation; source acceptance criteria.'),'Current status':ev.get('status','IN PROGRESS' if domain in ['Running','Identity','Adaptation'] else 'NOT STARTED'),'Evidence':ev.get('evidence',''),'Source key':key}
with (root/'docs/IXHUA-REQUIREMENTS-MATRIX.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(next(iter(rows.values()))));w.writeheader();w.writerows(rows.values())
(root/'docs/source-provenance.json').write_text(json.dumps({'source':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'deduplicated_sections':len(rows),'method':'Source-section matrix restored from the complete directive. A section is not tested until all its connected requirements pass.','latest_user_constraint':'Commit and verify a recoverable checkpoint after every tested vertical slice; checkpoints are not release candidates.'},indent=2))
print(f'{len(rows)} deduplicated source sections linked; statuses preserved from evidence.')
