'use strict';
const os = require('node:os');
const net = require('node:net');
function privateIPv4(address) {
  if (net.isIP(address) !== 4) return false;
  const [a,b] = address.split('.').map(Number);
  return a === 10 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31;
}
function lanAddresses(interfaces) {
  if(interfaces===undefined) interfaces=os.networkInterfaces();
  const list = [];
  for (const [name, values] of Object.entries(interfaces)) {
    for (const value of values || []) {
      if (value.internal || !privateIPv4(value.address)) continue;
      if (list.some(x => x.address === value.address)) continue;
      const virtual = /docker|veth|vethernet|wsl|virtual|vmware|vbox|bridge|tun|vpn|tailscale|zerotier/i.test(name);
      list.push({name, address:value.address, virtual});
    }
  }
  return list.sort((a,b) => Number(a.virtual)-Number(b.virtual) || a.name.localeCompare(b.name));
}
function normalizeAddress(address) { return String(address || '').replace(/^::ffff:/, ''); }
function loopback(address) { return ['127.0.0.1','::1'].includes(normalizeAddress(address)); }
function localPeer(address) { return loopback(address) || privateIPv4(normalizeAddress(address)); }
module.exports = {privateIPv4, lanAddresses, normalizeAddress, loopback, localPeer};
