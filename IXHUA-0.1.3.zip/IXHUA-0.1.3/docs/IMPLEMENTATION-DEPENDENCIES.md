# IXHUA implementation dependencies

The interrupted run's implementation record controls reconstruction. The preserved project is commit `181a324`; source requirements remain in `IXHUA-SOURCE-OF-TRUTH.txt`.

1. Canonical profile, duration/date handling, validation and atomic persistence → independent Running prescriptions → runner-priority allocation → real Running screens, history and feedback → Running checkpoint.
2. Deep Athlete Identity and conditional onboarding → validated profile → program selection and product hierarchy → persisted/reloadable onboarding checkpoint.
3. Strength progression and one concurrent Running/Strength/Hybrid planner → Today, Training, Plan and Progress → connected UI checkpoint.
4. Exercise database and anatomical primary/secondary mappings → exported muscle meshes and skeleton → exercise-specific animated popup, props, controls and fallbacks → anatomy checkpoint.
5. Local label extraction → camera/file capture → review/edit/portion confirmation → atomic food log → scan checkpoint.
6. Life events and available windows → proposals with before/after changes → Ask IXHUA → explicit apply/undo → preference learning → adaptation checkpoint.
7. Complete source acceptance criteria, research provenance, remaining product/native boundaries, mobile layouts, persistence and launcher checks → final fixes checkpoint → RC gate.

Each recovery checkpoint must pass relevant tests, exist as a Git commit and pass `git bundle verify`. Saved bundles contain source and history and are recovery artifacts, never Release Candidates. Native device results and external integration success remain unverified until actually performed; neither DOM tests nor browser emulation establish physical iPhone or Watch validation.
