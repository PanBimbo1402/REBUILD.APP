# Recovery checkpoints

These are source-control recovery points, not release candidates. Production and the remote GitHub repository are unchanged.

Each tested vertical slice is committed. `scripts/checkpoint.cjs` creates a full Git bundle, verifies it, clones it into a separate directory, checks the recovered commit, runs Git object verification and executes the critical build, domain/integration and mobile-browser tests from the recovered clone. It rejects a clone that changes source during tests. The bundle is then retained separately from this temporary workspace.

To recover: `git clone IXHUA-RECOVERY-01-running.bundle ixhua`, enter the new folder, and run `npm ci`. Read `docs/WORK-CONTINUITY.md` before continuing. A later numbered bundle contains earlier checkpoints too.

The release matrix and acceptance evidence travel inside the Git history. Browser-emulated tests are separate from physical iPhone and native-device results. A checkpoint is not permission to publish, push, or approve Native Device Beta.
