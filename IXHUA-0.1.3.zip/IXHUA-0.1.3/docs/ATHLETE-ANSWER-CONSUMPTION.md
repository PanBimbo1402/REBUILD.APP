# Athlete Identity checkpoint: answer → behavior

This document describes the actual checkpoint implementation. It does not certify the whole Release Candidate or replace the master requirements matrix.

| Answer | Stored field | Actual consumer and result |
|---|---|---|
| Main identity | `athlete.primary` | Onboarding branches; `training.demands` protects that domain; Today, Training, Progress and Plan use the same identity. |
| Secondary qualities | `secondary` | Adds domain assessment and real running, lifting, aerobic, mobility, capability or assessed power work; omitted support has an explicit reason. |
| Hybrid priority | `hybridPriority` | Allocates the preferred domain first under constrained availability; changes goal emphasis and Progress order. |
| Custom leading quality | `customPriority` | Protects that selected quality first; determines the first Training tab and Progress focus. |
| Goal in own words | `customGoal` | Displayed on Custom Today/Training/Plan and included in structured coach context. Free text is not silently interpreted as a medical or scheduling instruction. |
| Name | `name`, legacy-compatible `profile.name` | Personal profile and structured coach context; never a training dose input. |
| Language | `language` | Localized dates and existing English/Spanish navigation. Full Spanish prose coverage remains a separate release requirement. |
| Units | `units` | Feet/inches or cm input, lb/kg display and canonical kg storage, mile/km running records, load increments and Progress labels. |
| Age, height, weight, physiology | `age`, `heightCm`, `weightKg`, `sex` | Existing calorie estimator receives canonical values. Missing physiology or manual-only choice means no automatic target. Age never downgrades lifting experience. |
| Running goal | `running.goal` | Verified Running engine chooses baseline, phase, dose and appropriate goal-specific work. |
| Completion vs performance | `running.intent` | Completion preference replaces structured quality slots with easy practice. Performance uses Running's existing baseline and consistency eligibility checks; target time alone cannot force a hard session. |
| Target time | `running.targetSeconds` | Goal comparison and deadline context in actual Running / Hybrid surfaces; deliberately not used to invent an achieved pace or current capacity. |
| Custom event name / distance | `running.customGoal`, `customDistanceKm` | Real goal context displayed with the prescription and passed to the coach. The app provides a general base plan for custom events; it does not claim specialist ultra/triathlon programming. |
| Date / approximate month / weeks / no deadline | `goalDate`, `deadlineKind`, `goalMonth`, `goalWeeks` | Canonical date anchors Running phase and taper; close-date warnings compare baseline and event. Month uses its last day, explicitly described as approximate. |
| Continuous running capacity | `continuousMinutes` | Running engine chooses run/walk versus continuous practice and initial bout lengths. |
| Recent weekly time and current days | `weeklyMinutes`, `currentDays` | Establish per-session starting dose; no assumed mileage. |
| Consecutive consistent weeks | `consistentWeeks` | Gates quality sessions and return-to-running progression. |
| Running experience | `running.experience` | Controls Running eligibility and repeat structure, independently of lifting. |
| Requested running days | `running.days` | Creates that many requested runs; conflicts are explicit, supporting lifts cannot silently replace them. |
| Benchmark time, distance and date | `benchmarkSeconds`, `benchmarkDistanceKm`, `benchmarkDate` | Recent eligible benchmarks inform reference pace; stale/short benchmarks are retained as entered baselines without inferred race fitness. `9.15` is 555 seconds. |
| Environment | `running.environment` | Saved with each actual prescription; terrain/treadmill guidance and measured-distance expectations change. No GPS data is invented. |
| Long-run day and window | `longDay`, `longMinutes` | Day preference in placement and a separate long-run duration window. A failing regression proved that the usual shorter window was incorrectly overriding this answer; the cap was corrected without replacing the engine. |
| Simple / run-walk / continuous / varied | `running.preference` | Simple replaces quality intervals; run-walk retains explicit walking breaks. Continuous remains gated by actual capacity. |
| Running-related discomfort | `running.pain` | Withholds running appointments and explains the hold. It does not construct a rehabilitation plan. |
| Free-text running constraints | `running.constraints` | Shown before training and included in coach context. Collected to preserve the user's stated limitations; not diagnosed or falsely claimed to be automatically resolved. |
| Recent lifting days, consistency and break | `strength.currentDays`, `consistentWeeks`, `breakWeeks` | Low recent consistency or a break reduces working-set dose and raises reps in reserve while retaining experience. Current frequency is retained in profile/coach context; requested future frequency remains explicit. |
| Lifting discomfort / avoided exercises | `strength.pain`, `avoid` | Withholds lifting appointments or selects movement-matched available alternatives. |
| Lifting experience | `strength.experience` | Working-set dose, architecture and benchmark usage; independent from running experience and age. |
| Lifting goal and requested days | `strength.goal`, `strength.days` | Full body, upper/lower or five-day muscle emphasis, rep ranges and number of lifting demands. |
| Preferred split | `strength.split` | Honored when frequency and experience support it; otherwise a feasible structure is chosen and explained. |
| Bench/squat/deadlift benchmarks | `benchKg`, `squatKg`, `deadliftKg` | Experienced users get an explicitly estimated conservative first working load for that exact exercise. Actual completed sets replace the estimate. Never used as an invented logged PR. |
| Bench goal | `targetBenchKg` | Strength / Hybrid goal panels and coach context. It cannot override safe initial load selection. |
| Muscle emphasis | `strength.priorities` | Adds matching accessories and/or working sets within the session budget. Omitted exercises are recorded. |
| Available days / time / duration | `days`, `preferredTime`, `minutes` | Actual appointment dates/times and executable exercise budget. Ten-minute sessions contain real movements. |
| Wake / bedtime / commute buffer | `schedule` | Bounds placement and expands real commitments, including overnight spillover. |
| Physical work demand | `schedule.workDemand` | High-demand sessions prefer dates without known physically demanding work commitments. No inference is made from an unlogged shift. |
| Split sessions allowed | `splitSessions` | Permits multiple sessions only with compatible stress and at least three hours between start times. |
| Equipment | `equipment` | Filters exercises and movement-matched replacements. No unavailable machine is silently prescribed. |
| Aerobic preference | `cardioPreference` | Real cycling / walking / rowing / swimming / hiking prescriptions, stored separately from Running. |
| Mobility needs | `capability.needs` | Chooses targeted mobility practice; balance requests add capability practice. |
| Plyometric interest / experience / surface / landing / pain | `plyo` | Off, withheld, landing preparation, introductory contacts or history-supported reactive practice; actual landing feedback is required for advancement. |
| Balance / chair stands / comfortable walk | `capability` | Chooses support and movements and caps walking duration. Unknown baselines remain unknown. |
| Capability goal | `capability.goal` | Longevity priority and baseline panels keep the actual desired activity visible. It is context, not a validated performance result. |
| Nutrition goal / overall activity | `nutrition.goal`, `activity` | Independent calorie direction and activity factor; choosing hypertrophy does not silently force a surplus when maintenance was selected. |
| Manual / clinician-set targets | `nutrition.manualOnly` | Prevents automatic estimates; Settings accepts and persists manual targets. |
| Food pattern / allergies / dislikes | `diet`, `allergies`, `dislikes` | Filters existing meal suggestions and enters coach context. Ingredient-string filtering cannot certify allergen absence or cross-contact safety. |
| Likes / budget | `likes`, `budget` | Orders compatible meal ideas by preferred ingredients and economical staple ingredients. No live product price is claimed. |

`onboardingDraft` retains raw form values, prior-step drafts and the normalized profile through reload. Applying setup atomically saves the athlete and generated appointments. Completed sessions, food, weight and sleep records remain. Applying a different athlete program is deferred while a workout is active; answers remain saved.

The accepted plan is used by the actual workout screens. Completed sets, loads and RIR affect the next reviewed strength plan. Running uses its verified actual-history feedback. Capability and plyometrics use recorded effort, discomfort and landing control. Plan regeneration is reviewable before applying; the broader natural-language proposal/undo system is checkpoint 06.

Evidence: `tests/ixhua-athlete.test.cjs`, `tests/ixhua-athlete.mobile.cjs`, `tests/ixhua-running.test.cjs`, `tests/ixhua-running.mobile.cjs`, and the corresponding records under `verification/ixhua/`. Mobile tests are actual Chromium rendering and interaction under phone-sized viewports, not a physical iPhone test.

Live AI execution remains `BLOCKED — EXTERNAL DEPENDENCY`: server-side `OPENAI_API_KEY` and `IXHUA_AI_MODEL` are not configured in the acceptance environment. Every persona verifies the actual request payload and the truthful 503 UI state. Native Watch/Health implementation and hardware acceptance remain separate unfinished release rows; the browser shows no invented readings. The identity checkpoint verifies the browser application, not Native Device Beta.
