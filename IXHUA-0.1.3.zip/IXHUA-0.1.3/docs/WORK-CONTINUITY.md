# Resume here

Source of truth: `docs/IXHUA-SOURCE-OF-TRUTH.txt`. The full document was read in the interrupted work. Use the existing requirements matrix and reconstruction record; do not restart or repeat the broad audit/research.

Current slice: Athlete Identity checkpoint 02. The complete original Running checkpoint is `a412542e90f3f00d30ab36abb804d155fa8fbdf9`. Its engine was preserved. Only a failing long-window regression justified a one-line duration-cap correction; the Running Progress date filter was connected to the new range control.

- `js/ixhua/core.js`: canonical duration/date/timer handling, nested athlete schema, validation, sanitized import and atomic transactions.
- `js/ixhua/running.js`: baseline-driven run/walk, easy, interval and long prescriptions; goal/phase data; actual-history feedback; measured/benchmark pace references; shift-aware placement; runner-first allocation. Supporting strength cannot displace requested runs.
- `js/ixhua/running-ui.js`: running profile and review/apply, persisted draft, actual segment popup, start/pause/resume/end, distance/effort/notes, summaries, separate Running history, remaining-run feedback.
- `js/ixhua/bridge-source.js`: integrates into the existing working app and storage. Strength, Nutrition and other legacy workflows remain until their connected replacements pass their own gates. `build.cjs` assembles the two extension sources.
- `tests/ixhua-running.test.cjs`: 17 domain/property tests including 100,000 varied prescriptions. `tests/ixhua-running.mobile.cjs`: actual browser flow at 375×812, 390×844 and 844×390; screenshots and JSON are under `verification/ixhua/`.
- Existing engine and QR gates: 34 tests pass before and after reconstruction.

Athlete files: `onboarding.js`, `training.js`, `athlete-ui.js`, `athlete-nutrition.js`, `exercises.js`, integrated by `bridge-source.js`. Six identities and eight persona journeys use shared profile, plan and actual history. See `ATHLETE-ANSWER-CONSUMPTION.md`. `tests/ixhua-athlete.test.cjs` and `tests/ixhua-athlete.mobile.cjs` cover the slice.

Next after checkpoint 02 recovery verification: remaining unified-session / Training UI acceptance (checkpoint 03), then anatomical mesh viewer/mappings (04), complete local label OCR workflow (05), Ask/Plan adaptation (06), remaining source acceptance requirements. Do not repeat the broad audit or research. Never have more than one major uncheckpointed slice.

Still to improve in subsequent slices: require explicit approval for future-dose changes and validate their resulting schedule; fully implement plyometrics, real anatomical assets and OCR. These are not declared completed by the Running checkpoint.

Local test runtime: pinned `@sparticuz/chromium@153.0.0`; `IXHUA_TEST_CHROMIUM` can identify a local Chromium executable. Managed cloud Browser refuses loopback URLs. This is not a claim that physical iPhone/Watch testing passed.

Checkpoint 02 includes independent recovery-clone tests in `scripts/checkpoint.cjs`: build, all domain/preview tests, Running mobile lifecycle and all eight athlete browser journeys (A first-5K/3-day, B sub-20/6-run-day, C novice strength, D 5-day arms hypertrophy, E hybrid 225/sub-25, F general, G experienced age-60 longevity, H Custom). All eight also inspect role-specific Ask context, weekly review and explicit native-device boundaries. Dependencies can be reused through NODE_PATH; application code and assets come only from the clean Git clone. The outside recovery JSON records the exact tested commit.

If the cached Chromium executable is shorter than 209022176 bytes, restore it atomically from the already downloaded `node_modules/@sparticuz/chromium/bin/chromium.br`; do not redownload it. This happened after the earlier interrupted operation. Single-process Chromium needs a fresh browser process per persona.
