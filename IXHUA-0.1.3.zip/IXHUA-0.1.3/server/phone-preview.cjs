'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {loopback, localPeer} = require('../scripts/preview-network.cjs');
const {inspect:inspectOwnerSource} = require('../scripts/owner-build.cjs');
const QRCode = require('../scripts/vendor/qrcode-terminal/vendor/QRCode');
const levels = require('../scripts/vendor/qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel');
const root = path.resolve(__dirname, '..');
const escapeHTML = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function buildFingerprint() {
  const hash = crypto.createHash('sha256');
  const visit = relative => {
    const full = path.join(root, relative);
    if (fs.statSync(full).isDirectory()) {
      fs.readdirSync(full).sort().forEach(name => visit(path.join(relative, name)));
    } else {
      hash.update(relative.split(path.sep).join('/')).update('\0').update(fs.readFileSync(full)).update('\0');
    }
  };
  ['index.html','manifest.json','package.json','build.cjs','js','css','assets','server','scripts','config'].forEach(visit);
  return hash.digest('hex');
}
function qrSvg(value) {
  const code = new QRCode(-1, levels.M);
  code.addData(value);
  code.make();
  const n = code.getModuleCount();
  const segments = [];
  for (let row=0; row<n; row++) for (let col=0; col<n; col++) {
    if (code.isDark(row,col)) segments.push(`M${col+4},${row+4}h1v1h-1z`);
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n+8} ${n+8}" width="360" height="360" shape-rendering="crispEdges" role="img" aria-label="Open the current IXHUA owner preview"><rect width="100%" height="100%" fill="white"/><path d="${segments.join('')}" fill="black"/></svg>`;
}
function page(title, content, script = '') {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>${escapeHTML(title)}</title><link rel="stylesheet" href="/preview/style.css"></head><body><main class="preview-shell"><p class="eyebrow">IXHUA · OWNER PHONE PREVIEW</p><h1>${escapeHTML(title)}</h1>${content}</main>${script?`<script src="${script}" defer></script>`:''}</body></html>`;
}
function createPhonePreview({addresses, port, protocol='http', clock=Date.now, ttlMs=8*60*60*1000, env=process.env}) {
  const token = crypto.randomBytes(24).toString('base64url');
  const nonce = crypto.randomBytes(16).toString('hex');
  const buildId = buildFingerprint();
  const createdAt = clock();
  const expiresAt = createdAt + ttlMs;
  const sessions = new Map();
  const attempts = new Map();
  const manifest = JSON.parse(fs.readFileSync(path.join(root,'config/phone-preview.json'),'utf8'));
  const sourceIdentity = inspectOwnerSource(root);
  const allowedHosts = new Set(['127.0.0.1','localhost',...addresses.map(x=>x.address)].map(x=>`${x}:${port}`));
  const makeLink = address => `${protocol}://${address}:${port}/pair#access=${token}&build=${buildId}`;
  const send = (res, status, data, type='application/json') => {
    res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(type==='application/json'?JSON.stringify(data):data);
  };
  const authenticated = req => {
    const value = /(?:^|;\s*)ixhua_preview=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie||'')?.[1];
    return value && sessions.get(value)>clock() && expiresAt>clock();
  };
  function status() {
    const services = [
      {name:'App and API server',state:'RUNNING',detail:'One process serves the existing application, its assets and /api endpoints.'},
      {name:'AI and image interpretation',state:env.OPENAI_API_KEY&&(env.IXHUA_AI_MODEL||env.REBUILD_AI_MODEL)?'CONFIGURED — LIVE TEST REQUIRED':'NOT CONFIGURED',detail:'Outside IXHUA 0.1 acceptance. Server-only OPENAI_API_KEY and IXHUA_AI_MODEL (legacy model alias supported). Configuration is not proof of a successful provider call.'},
      {name:'Food product database',state:env.OFF_USER_AGENT?(env.OFF_ENV==='production'?'CONFIGURED — LIVE TEST REQUIRED':'STAGING — LIVE PRODUCT TEST BLOCKED'):'NOT CONFIGURED',detail:'OFF_USER_AGENT is required. Real product tests also need OFF_ENV=production.'}
    ];
    const blockers = manifest.requiredNonHardware.filter(x=>x.status!=='WORKING').map(x=>({id:x.id,reason:x.detail}));
    const sourceChanged = buildFingerprint()!==buildId;
    if (sourceChanged) blockers.unshift({id:'source-changed',reason:'Source files changed after startup. Stop and restart START-IXHUA before recording tests.'});
    for (const service of services.slice(1)) blockers.push({id:service.name,reason:service.state});
    return {mode:'owner-phone-preview',buildId,sourceProduct:manifest.sourceProduct,releaseStatus:manifest.releaseStatus,sourceIdentity,
      ownerAcceptance:{...manifest.ownerAcceptance,readyForTesting:sourceIdentity.verified&&!sourceChanged,physicalIPhone:'AWAITING OWNER TEST',sourceCommit:sourceIdentity.commit},
      transport:protocol,expiresAt:new Date(expiresAt).toISOString(),sourceChanged,services,
      requiredNonHardware:manifest.requiredNonHardware,nativeOnly:manifest.nativeOnly,checks:manifest.checks,
      releaseGate:{scope:'FULL IXHUA RELEASE CANDIDATE',eligibleForOwnerAcceptance:false,blockers,physicalIPhone:'NOT RUN BY BUILD ENVIRONMENT',nativeBeta:'REQUIRES EXPLICIT OWNER APPROVAL',production:'NOT APPROVED'}};
  }
  async function handle(req,res) {
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('X-Frame-Options','DENY');
    res.setHeader('X-Robots-Tag','noindex, nofollow, noarchive');
    if (!localPeer(req.socket.remoteAddress) || !allowedHosts.has(req.headers.host)) {
      send(res,403,{error:'This preview accepts only this computer and its trusted local-network addresses.'});return true;
    }
    const expectedOrigin = `${protocol}://${req.headers.host}`;
    if ((req.headers.origin && req.headers.origin!==expectedOrigin) || req.headers['sec-fetch-site']==='cross-site') {
      send(res,403,{error:'Cross-origin preview requests are not allowed.'});return true;
    }
    const url = new URL(req.url,expectedOrigin);
    const p = url.pathname;
    if (p==='/preview/health' && req.method==='GET') {
      send(res,200,{mode:'owner-phone-preview',nonce,buildId,ready:clock()<expiresAt,sourceIdentity});return true;
    }
    if (['/preview/style.css','/preview/pair.js'].includes(p) && req.method==='GET') {
      const file = p.endsWith('.css')?'phone-preview.css':'preview-pair.js';
      const dir = p.endsWith('.css')?'css':'js';
      send(res,200,fs.readFileSync(path.join(root,dir,file),'utf8'),p.endsWith('.css')?'text/css':'text/javascript');return true;
    }
    if (p==='/pair' && req.method==='GET') {
      res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
      send(res,200,page('Open your preview.',`<p id="pair-status" role="status">Checking the preview link…</p><p>Keep START-IXHUA running on your computer. Use the same trusted Wi-Fi network.</p><p>This browser preview does not validate native health, watch or background capabilities.</p><p><a href="/">Return to the app</a></p><noscript>Enable JavaScript in Safari, then scan the QR again.</noscript>`,'/preview/pair.js'),'text/html');return true;
    }
    if (p==='/preview/pair' && req.method==='POST') {
      const key = req.socket.remoteAddress;
      const now = clock();
      for (const [k,values] of attempts) if (!values.some(t=>now-t<60000)) attempts.delete(k);
      const hits = (attempts.get(key)||[]).filter(t=>now-t<60000);
      if(hits.length>=10 || attempts.size>=128&&!attempts.has(key)) {send(res,429,{error:'Too many pairing attempts. Wait one minute and scan again.'});return true;}
      attempts.set(key,[...hits,now]);
      if(req.headers['content-type']?.split(';')[0]!=='application/json') {send(res,415,{error:'Use the QR pairing page.'});return true;}
      let raw='';
      try {
        for await(const chunk of req) {
          raw+=chunk;
          if(Buffer.byteLength(raw)>1024) {send(res,413,{error:'Pairing request too large.'});return true;}
        }
        const data=JSON.parse(raw);
        const candidate=Buffer.from(typeof data.token==='string'?data.token:'');
        const correct=Buffer.from(token);
        if(clock()>=expiresAt || data.buildId!==buildId || candidate.length!==correct.length || !crypto.timingSafeEqual(candidate,correct)) {
          send(res,401,{error:'This link is invalid or expired. Scan the QR from the current START-IXHUA window.'});return true;
        }
        for(const [id,time] of sessions) if(time<=clock()) sessions.delete(id);
        if(sessions.size>=32) {send(res,429,{error:'Preview device limit reached. Restart START-IXHUA to clear pairings.'});return true;}
        const id=crypto.randomBytes(32).toString('hex');
        sessions.set(id,expiresAt);
        const maxAge=Math.floor((expiresAt-clock())/1000);
        res.setHeader('Set-Cookie',`ixhua_preview=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${protocol==='https'?'; Secure':''}`);
        send(res,200,{ok:true,buildId});return true;
      } catch {send(res,400,{error:'Invalid pairing request. Scan the QR again.'});return true;}
    }
    if(p==='/owner-preview' && req.method==='GET') {
      if(!loopback(req.socket.remoteAddress)) {send(res,403,{error:'The QR control page opens only on the computer running START-IXHUA.'});return true;}
      res.setHeader('Content-Security-Policy',"default-src 'none'; style-src 'self'; img-src data:; base-uri 'none'; frame-ancestors 'none'; form-action 'none'");
      let selected=addresses.find(x=>x.address===url.searchParams.get('address')) || addresses[0];
      const live=status();
      const choice=addresses.length>1?`<nav class="network-choices" aria-label="Network address">${addresses.map(a=>`<a href="/owner-preview?address=${encodeURIComponent(a.address)}">${escapeHTML(a.name)} · ${a.address}${a.virtual?' (virtual/VPN)':''}</a>`).join('')}</nav>`:'';
      const phone=selected?`<img class="qr" src="data:image/svg+xml;base64,${Buffer.from(qrSvg(makeLink(selected.address))).toString('base64')}" alt="Scan this QR with your iPhone Camera"><p class="small">${escapeHTML(selected.name)} · ${selected.address}:${port}</p><details><summary>Copy the phone link instead</summary><p class="wrap">${escapeHTML(makeLink(selected.address))}</p></details>`:'<p class="warning">No private Wi-Fi/Ethernet IPv4 address found. Connect the computer to your home network and restart. Phone preview is not ready.</p>';
      send(res,200,page('Test it on your iPhone.',`<p class="lead">1. Same trusted Wi-Fi. &nbsp; 2. Scan with Camera. &nbsp; 3. Tap the link and open Safari.</p><div class="preview-grid"><section>${phone}${choice}<a class="primary-link" href="${escapeHTML(makeLink('127.0.0.1'))}">Open the same app on this computer</a></section><section><p class="eyebrow">CURRENT SOURCE</p><h2>${escapeHTML(manifest.sourceProduct)}</h2><p>Build <code>${buildId.slice(0,12)}</code></p><p>Stable Athlete Identity baseline <code>${manifest.ownerAcceptance.baselineCommit.slice(0,12)}</code>.</p><p>${escapeHTML(sourceIdentity.status)}${sourceIdentity.commit?' · <code>'+sourceIdentity.commit.slice(0,12)+'</code>':''}</p><p>Test your questions, program, Today, Training, Progress and Plan.</p><p><strong>Runner → Strength &amp; Muscle → Hybrid → General Fitness → Longevity → Custom</strong></p><p>Tap <strong>Owner testing</strong> in the app, then <strong>Start fresh test</strong> between identities. Your feedback stays saved; the last round can be downloaded.</p><p class="small">This owner acceptance covers IXHUA 0.1. The full IXHUA Release Candidate and Native Device Beta remain separate gates.</p></section></div><section><h2>Keep this window running.</h2><p>Stop: press Ctrl+C in the START-IXHUA terminal. Restart: double-click START-IXHUA again and scan the new QR. Links expire after eight hours or when the server stops.</p><p>${protocol==='https'?'HTTPS is enabled. The iPhone must already trust a certificate valid for the selected address.':'This local HTTP preview is not encrypted. Use a trusted home network and test data. Live browser camera access needs trusted HTTPS; photo upload and manual barcode entry are available.'}</p><p>This owner copy uses port 4319 by default, separate from the earlier 4318 preview. Your phone’s logs stay in that browser. They do not automatically sync to the computer. Keep the same network address and port, and export data in Settings before changing either.</p><details><summary>Phone cannot open the link?</summary><ol><li>Keep the computer awake and connected to the same home Wi-Fi as the phone. Avoid guest Wi-Fi with device isolation.</li><li>If Windows asks, allow Node.js on your trusted Private network. Do not disable the firewall.</li><li>If several addresses are listed above, choose the physical Wi-Fi or Ethernet adapter. A VPN or virtual adapter may be unreachable.</li><li>After changing Wi-Fi, stop and restart START-IXHUA and scan the new QR.</li><li>If the terminal shows a startup error, resolve that error before retrying the phone.</li></ol></details></section>`),'text/html');return true;
    }
    if(!authenticated(req)) {
      if(p.startsWith('/api/') || p.startsWith('/preview/')) send(res,401,{error:'Phone preview pairing expired. Scan the QR in START-IXHUA again.'});
      else send(res,401,page('Scan the current QR.',`<p>Open START-IXHUA on your computer, then scan its QR with your iPhone Camera. Old pairings expire when the server restarts.</p>`),'text/html');
      return true;
    }
    if(p==='/preview/status' && req.method==='GET') {send(res,200,status());return true;}
    if(p.startsWith('/preview/')) {send(res,404,{error:'Unknown preview endpoint.'});return true;}
    return false;
  }
  return {handle,status,buildId,nonce,makeLink,expiresAt};
}
module.exports={createPhonePreview,qrSvg,buildFingerprint};
