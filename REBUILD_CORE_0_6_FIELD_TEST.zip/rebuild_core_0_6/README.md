# REBUILD Core 0.6 — Field Test

Founding date: September 6, 2026.

0.6 field-test changes:
- iPhone safe-area spacing.
- Training tabs: Strength, Cardio, Running, Mobility.
- Rest timer Start/Resume, Stop/Pause, Reset behavior fixed.
- PR-anchored starting-weight suggestions extended to accessory movements; actual workout history should eventually outrank these estimates.
- Distinct compact exercise thumbnails plus the existing detailed form popup.
- Mobility/plyometric preparation cards with timing guidance and logging UI.
- Added movement-prep onboarding questions.
- Daily morning bodyweight logging with 1W/2W/3W/1M/3M/6M/1Y/ALL trend views.
- Mobile UI polish.

This remains a prototype. Suggested weights and nutrition are estimates, not medical or performance guarantees.
